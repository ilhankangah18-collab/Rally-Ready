import { formatScore, type ScoreEntry } from "../game/storage";
import type { PowerType } from "../game/engine";

function TrophyIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M6 3h8v4.5a4 4 0 0 1-8 0V3Z" />
      <path d="M6 4.5H3.8v1.7A2.8 2.8 0 0 0 6.6 9M14 4.5h2.2v1.7A2.8 2.8 0 0 1 13.4 9M10 11.5V15M6.8 17h6.4" />
    </svg>
  );
}

export function PowerGlyph({ type, className = "h-4 w-4" }: { type: PowerType; className?: string }) {
  if (type === "wide") {
    return (
      <svg viewBox="0 0 16 16" className={className} fill="currentColor" aria-hidden="true">
        <rect x="1.5" y="3" width="13" height="2.6" rx="1.3" />
        <rect x="1.5" y="10.4" width="13" height="2.6" rx="1.3" />
      </svg>
    );
  }
  if (type === "slow") {
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden="true">
        <circle cx="8" cy="8" r="5.6" />
        <path d="M8 4.7V8l2.3 1.4" />
      </svg>
    );
  }
  if (type === "stagger") {
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" aria-hidden="true">
        <path d="M8 1.5v13M3 2.8l10 10.4M13 2.8 3 13.2M8 3.5 6.6 2.1M8 3.5l1.4-1.4M8 12.5l-1.4 1.4M8 12.5l1.4 1.4M5.4 4.3 3.8 3.9M5.4 11.7l-1.6.4M10.6 4.3l1.6-.4M10.6 11.7l1.6.4" />
      </svg>
    );
  }
  if (type === "shield") {
    return (
      <svg viewBox="0 0 16 16" className={className} fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" aria-hidden="true">
        <path d="M8 1.8 13 3.7v4c0 3.1-2.2 5.3-5 6.5-2.8-1.2-5-3.4-5-6.5v-4L8 1.8Z" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 16 16" className={className} fill="currentColor" aria-hidden="true">
      <path d="M9.1.6 2.2 9.2h4l-1.3 6.2 7.2-9.1h-4L9.1.6Z" />
    </svg>
  );
}

const POWER_ITEMS: { type: PowerType; name: string; desc: string; color: string; tag: string }[] = [
  {
    type: "wide",
    name: "Wide paddle",
    desc: "+60% reach for 8 seconds.",
    color: "#d4ff57",
    tag: "DEFEND",
  },
  {
    type: "slow",
    name: "Slo-mo",
    desc: "The ball runs 36% slower for 5s.",
    color: "#65ead5",
    tag: "CONTROL",
  },
  {
    type: "shield",
    name: "Shield",
    desc: "Auto-saves the next goal against you.",
    color: "#b9a1ff",
    tag: "INSURANCE",
  },
  {
    type: "surge",
    name: "Surge charge",
    desc: "Instantly banks 60% of a power shot.",
    color: "#ff6b4a",
    tag: "OFFENSE",
  },
  {
    type: "stagger",
    name: "Stagger",
    desc: "Freezes the rival paddle for 4.5s — one per match.",
    color: "#8be1ff",
    tag: "DEFENSE",
  },
];

export { POWER_ITEMS };

const RANK_LABEL = ["01", "02", "03", "04", "05", "06", "07", "08"];

export function ScoreTable({
  scores,
  highlightId,
  rows = 6,
  showBest = false,
}: {
  scores: ScoreEntry[];
  highlightId?: string | null;
  rows?: number;
  showBest?: boolean;
}) {
  return (
    <div>
      <div className="grid grid-cols-[24px_minmax(0,1fr)_54px_62px] gap-2 border-b border-white/[0.06] px-2 pb-1.5 font-mono text-[8px] uppercase tracking-[0.16em] text-white/25">
        <span>#</span>
        <span>Pilot</span>
        <span className="text-right">Rally</span>
        <span className="text-right">Score</span>
      </div>
      <ol>
        {scores.slice(0, rows).map((entry, i) => {
          const fresh = entry.id === highlightId;
          return (
            <li
              key={entry.id}
              className={`grid grid-cols-[24px_minmax(0,1fr)_54px_62px] items-center gap-2 rounded-md px-2 py-[7px] text-[11px] transition-colors ${
                fresh
                  ? "bg-acid/[0.08] ring-1 ring-inset ring-acid/20"
                  : i === 0 && showBest
                    ? "bg-white/[0.03]"
                    : "hover:bg-white/[0.025]"
              }`}
            >
              <span
                className={`font-mono text-[9px] tracking-wider ${
                  i === 0 ? "text-acid" : i < 3 ? "text-white/55" : "text-white/20"
                }`}
              >
                {RANK_LABEL[i] ?? String(i + 1).padStart(2, "0")}
              </span>
              <span className="flex min-w-0 items-baseline gap-1.5">
                <span className={`truncate font-semibold tracking-wide ${fresh ? "text-acid" : "text-white/85"}`}>
                  {entry.tag}
                </span>
                {i === 0 && <TrophyIcon className="h-2.5 w-2.5 shrink-0 text-acid/70" />}
                <span className="hidden font-mono text-[8px] text-white/22 sm:inline">{entry.goals}</span>
                {fresh && <span className="font-mono text-[7px] tracking-widest text-acid/70">NEW</span>}
              </span>
              <span className="tnum text-right font-mono text-[9px] text-white/35">×{entry.rally}</span>
              <span className={`tnum text-right font-mono text-[10px] ${fresh ? "text-acid" : "text-white/70"}`}>
                {formatScore(entry.score)}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function PlayerCard({
  tag,
  best,
  scores,
  onTagChange,
}: {
  tag: string;
  best: number;
  scores: ScoreEntry[];
  onTagChange: (tag: string) => void;
}) {
  const bestRally = scores.reduce((max, s) => Math.max(max, s.rally), 0);

  return (
    <section className="panel relative overflow-hidden p-3.5">
      <div className="pointer-events-none absolute -right-8 -top-10 h-28 w-28 rounded-full bg-acid/[0.06] blur-2xl" />
      <div className="mb-3 flex items-center justify-between">
        <span className="eyebrow">Pilot profile</span>
        <span className="chip chip-acid !px-2 !py-0.5 !text-[7px]">
          <span className="h-1 w-1 rounded-full bg-acid" />
          LOCAL SAVE
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div className="logo-mark h-11 w-11 shrink-0">
          <span className="logo-bar left-[9px]" />
          <span className="logo-bar right-[9px]" />
          <span className="logo-ball" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <input
              className="field-tag !text-[13px] !px-1.5 !py-0.5"
              value={tag}
              maxLength={5}
              aria-label="Your pilot tag"
              onChange={(e) => onTagChange(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5))}
            />
            <span className="font-mono text-[7px] uppercase tracking-[0.14em] text-white/25">edit tag</span>
          </div>
          <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.14em] text-white/35">
            Local profile · solo circuit
          </p>
        </div>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="stat-tile">
          <span>Best score</span>
          <strong className="text-acid">{formatScore(best)}</strong>
        </div>
        <div className="stat-tile">
          <span>Longest rally</span>
          <strong>{bestRally || "–"}</strong>
        </div>
      </div>
    </section>
  );
}

export function Leaderboard({
  scores,
  highlightId,
  onOpenAll,
}: {
  scores: ScoreEntry[];
  highlightId?: string | null;
  onOpenAll: () => void;
}) {
  return (
    <section className="panel overflow-hidden">
      <div className="flex items-center justify-between border-b border-white/[0.07] px-3.5 py-2.5">
        <div className="flex items-center gap-2">
          <span className="grid h-6 w-6 place-items-center rounded-md border border-acid/20 bg-acid/[0.07] text-acid">
            <TrophyIcon className="h-3 w-3" />
          </span>
          <div>
            <h2 className="text-[11px] font-semibold leading-tight tracking-wide text-white/90">HIGH SCORES</h2>
            <p className="font-mono text-[7px] uppercase tracking-[0.16em] text-white/25">Local hall of fame</p>
          </div>
        </div>
        <span className="chip !px-2 !py-0.5 !text-[7px]">TOP 8</span>
      </div>
      <div className="p-1.5">
        <ScoreTable scores={scores} highlightId={highlightId} rows={6} showBest />
      </div>
      <div className="flex items-center justify-between border-t border-white/[0.06] px-3.5 py-2">
        <span className="font-mono text-[7px] uppercase tracking-[0.14em] text-white/22">Persists on this device</span>
        <button type="button" onClick={onOpenAll} className="link-btn !text-[8px]">
          VIEW ALL <span aria-hidden="true">↗</span>
        </button>
      </div>
    </section>
  );
}

export function PowerUps() {
  return (
    <section className="panel overflow-hidden">
      <div className="flex items-center justify-between border-b border-white/[0.07] px-3.5 py-2.5">
        <div>
          <h2 className="text-[11px] font-semibold leading-tight tracking-wide text-white/90">NEW MECHANICS</h2>
          <p className="font-mono text-[7px] uppercase tracking-[0.16em] text-white/25">Orbs drift in · grab with paddle</p>
        </div>
        <span className="chip !px-2 !py-0.5 !text-[7px]">05 DROPS</span>
      </div>
      <ul className="divide-y divide-white/[0.05] px-1.5">
        {POWER_ITEMS.map((item) => (
          <li key={item.type} className="flex items-center gap-2.5 px-2 py-[8px]">
            <span
              className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border"
              style={{
                color: item.color,
                borderColor: `${item.color}33`,
                background: `${item.color}0f`,
              }}
            >
              <PowerGlyph type={item.type} className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="text-[10.5px] font-semibold tracking-wide text-white/85">{item.name}</span>
                <span className="font-mono text-[6.5px] tracking-[0.14em] text-white/25">{item.tag}</span>
              </div>
              <p className="mt-0.5 text-[9.5px] leading-snug text-white/38">{item.desc}</p>
            </div>
          </li>
        ))}
      </ul>
      <div className="mx-1.5 mb-1.5 mt-0.5 flex items-center gap-2 rounded-lg border border-ember/15 bg-ember/[0.055] px-2.5 py-2">
        <div className="flex h-6 items-center gap-0.5">
          {[2, 4, 6, 8].map((h, i) => (
            <span key={h} className="w-[3px] rounded-sm bg-ember" style={{ height: h + 4, opacity: 0.35 + i * 0.2 }} />
          ))}
        </div>
        <p className="text-[9.5px] leading-snug text-white/45">
          <span className="font-semibold text-ember">Rally combo</span> multiplies each return. Fill the surge bar, then
          hit a 1.5× power shot. Every match drops one <span className="font-semibold text-[#8be1ff]">Stagger</span> orb.
        </p>
      </div>
    </section>
  );
}
