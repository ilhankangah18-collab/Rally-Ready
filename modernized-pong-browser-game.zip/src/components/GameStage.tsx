import { useEffect, useRef, useState } from "react";
import { Sfx } from "../game/audio";
import {
  NeonRallyEngine,
  type Difficulty,
  type GameMode,
  type GameStatus,
  type HudSnapshot,
  type RunResult,
} from "../game/engine";
import { formatDuration, formatScore } from "../game/storage";

type RunRank = { rank: number; isBest: boolean; best: number };

type Props = {
  best: number;
  tag: string;
  muted: boolean;
  suspended: boolean;
  onTagChange: (tag: string) => void;
  onRunEnd: (result: RunResult) => RunRank;
  onOpenRules: () => void;
  onOpenScores: () => void;
};

const MODE_KEY = "neon-rally:mode:v1";
const DIFFICULTY_KEY = "neon-rally:difficulty:v1";

const DIFFICULTY_OPTIONS: { value: Difficulty; label: string; sub: string }[] = [
  { value: "casual", label: "CASUAL", sub: "Readable" },
  { value: "classic", label: "CLASSIC", sub: "Balanced" },
  { value: "ranked", label: "RANKED", sub: "Heavy" },
];

function loadDifficulty(): Difficulty {
  try {
    const raw = localStorage.getItem(DIFFICULTY_KEY);
    if (raw === "casual" || raw === "classic" || raw === "ranked") return raw;
  } catch {
    /* noop */
  }
  return "casual";
}

const INITIAL_HUD: HudSnapshot = {
  status: "attract",
  mode: "solo",
  playerScore: 0,
  rivalScore: 0,
  score: 0,
  p2Score: 0,
  combo: 0,
  comboP2: 0,
  lastSide: 1,
  bestCombo: 0,
  bestComboP2: 0,
  rally: 0,
  bestRally: 0,
  surge: 0,
  surgeP2: 0,
  shield: false,
  shieldP2: false,
  wide: 0,
  wideP2: 0,
  slow: 0,
  time: 0,
  fps: 60,
  level: 1,
  winner: null,
  staggerSide: null,
  stagger: 0,
};

const STATUS_LABEL: Record<GameStatus, string> = {
  attract: "STANDBY",
  playing: "LIVE",
  paused: "PAUSED",
  gameover: "FINAL",
};

function loadMode(): GameMode {
  try {
    const raw = localStorage.getItem(MODE_KEY);
    if (raw === "local" || raw === "solo") return raw;
  } catch {
    /* noop */
  }
  return "solo";
}

function PlayIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" className={className} fill="currentColor" aria-hidden="true">
      <path d="M5 2.8v10.4c0 .7.8 1.1 1.4.7l7.3-5.2a.9.9 0 0 0 0-1.4L6.4 2.1A.9.9 0 0 0 5 2.8Z" />
    </svg>
  );
}

function PauseIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" className={className} fill="currentColor" aria-hidden="true">
      <rect x="3.3" y="2.5" width="3.3" height="11" rx="1" />
      <rect x="9.4" y="2.5" width="3.3" height="11" rx="1" />
    </svg>
  );
}

function RestartIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" className={className} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M13.2 7.9a5.2 5.2 0 1 1-1.6-3.7" />
      <path d="M13.4 2.2v3.4H10" />
    </svg>
  );
}

function Key({ children, wide = false }: { children: React.ReactNode; wide?: boolean }) {
  return <kbd className={`keycap ${wide ? "px-3" : ""}`}>{children}</kbd>;
}

function SideBadge({ label, tone }: { label: string; tone: "acid" | "ember" }) {
  return (
    <div
      className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border font-mono text-[10px] font-medium tracking-wider ${
        tone === "acid"
          ? "border-acid/25 bg-acid/10 text-acid"
          : "border-ember/25 bg-ember/10 text-ember"
      }`}
    >
      {label}
    </div>
  );
}

function TeamScore({
  side,
  score,
  label,
  sub,
}: {
  side: "player" | "rival";
  score: number;
  label: string;
  sub: string;
}) {
  const acid = side === "player";
  return (
    <div className={`flex items-center gap-2.5 ${acid ? "" : "flex-row-reverse text-right"}`}>
      <SideBadge label={acid ? "P1" : "P2"} tone={acid ? "acid" : "ember"} />
      <div className={acid ? "" : "flex flex-col items-end"}>
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[9px] uppercase tracking-[0.17em] text-white/40">{label}</span>
          <span className={`hidden font-mono text-[8px] tracking-widest sm:inline ${acid ? "text-acid/60" : "text-ember/60"}`}>
            {sub}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span
            key={score}
            className={`tnum animate-[pop-in_.28s_ease-out] text-[26px] font-semibold leading-none sm:text-[30px] ${
              acid ? "text-acid" : "text-ember"
            }`}
          >
            {String(score).padStart(2, "0")}
          </span>
          <div className="hidden items-center gap-[3px] sm:flex">
            {Array.from({ length: 7 }).map((_, i) => (
              <span
                key={i}
                className={`h-[3px] w-[5px] rounded-full transition-colors duration-300 ${
                  i < score ? (acid ? "bg-acid" : "bg-ember") : "bg-white/12"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MenuOverlay({
  mode,
  onModeChange,
  difficulty,
  onDifficultyChange,
  best,
  tag,
  coarse,
  onTagChange,
  onStart,
  onOpenRules,
  onOpenScores,
}: {
  mode: GameMode;
  onModeChange: (mode: GameMode) => void;
  difficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
  best: number;
  tag: string;
  coarse: boolean;
  onTagChange: (tag: string) => void;
  onStart: () => void;
  onOpenRules: () => void;
  onOpenScores: () => void;
}) {
  const local = mode === "local";
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center p-3 sm:p-6">
      <div className="absolute inset-0 bg-[#040a08]/50 backdrop-blur-[2px]" />
      <div className="overlay-card relative max-h-full w-full max-w-[530px] overflow-y-auto p-4 text-center sm:p-5">
        <div className="mb-2 flex items-center justify-center gap-2">
          <span className="chip chip-acid">
            <span className="h-1.5 w-1.5 rounded-full bg-acid" />
            {local ? "LOCAL 2P" : "SOLO ARENA"}
          </span>
          <span className="chip">FIRST TO 7</span>
        </div>
        <p className="eyebrow mb-1">{local ? "Two seats · one keyboard" : "A modern pong, wired differently"}</p>
        <h2 className="display text-[30px] leading-[0.94] text-white sm:text-[46px]">
          RALLY <span className="text-acid">READY?</span>
        </h2>
        <p className="mx-auto mt-1.5 max-w-[360px] text-[12px] leading-relaxed text-white/55 sm:text-[12.5px]">
          {local
            ? "P1 vs P2 face to face. Chain returns, bank surge shots and break the rival's run."
            : "Outplay the machine, stack your combo and unleash a surge shot. Every return is points."}
        </p>

        <div className="mt-2.5 grid grid-cols-2 gap-1 rounded-xl border border-white/10 bg-black/35 p-1" role="group" aria-label="Match mode">
          {(["solo", "local"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => onModeChange(m)}
              aria-pressed={mode === m}
              className={`seg-button ${mode === m ? "seg-button-active" : ""}`}
            >
              {m === "solo" ? "SOLO" : "LOCAL 2P"}
            </button>
          ))}
        </div>

        {!local && (
          <div className="mt-2 grid grid-cols-3 gap-1" role="group" aria-label="Difficulty">
            {DIFFICULTY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => onDifficultyChange(opt.value)}
                aria-pressed={difficulty === opt.value}
                className={`difficulty-chip ${difficulty === opt.value ? "difficulty-chip-active" : ""}`}
              >
                <span>{opt.label}</span>
                <small>{opt.sub}</small>
              </button>
            ))}
          </div>
        )}

        <button type="button" onClick={onStart} className="btn btn-primary mt-2.5 w-full text-[14px]">
          <PlayIcon />
          {local ? "START MATCH" : "START MATCH"}
          <span className="ml-1 hidden rounded border border-black/20 bg-black/10 px-1.5 py-0.5 font-mono text-[9px] tracking-wider opacity-70 sm:inline">
            ENTER
          </span>
        </button>

        <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-left">
          {local ? (
            <>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key>W</Key>
                  <Key>S</Key>
                </div>
                <span>P1 move</span>
              </div>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key wide>{coarse ? "2FINGERS" : "↑ / ↓"}</Key>
                </div>
                <span>P2 move</span>
              </div>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key wide>SPACE</Key>
                </div>
                <span>Pause</span>
              </div>
            </>
          ) : (
            <>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key>W</Key>
                  <Key>S</Key>
                </div>
                <span>Move</span>
              </div>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key wide>{coarse ? "DRAG" : "MOUSE"}</Key>
                </div>
                <span>{coarse ? "Steer" : "Aim"}</span>
              </div>
              <div className="control-tile">
                <div className="mb-1 flex gap-1">
                  <Key wide>SPACE</Key>
                </div>
                <span>Pause</span>
              </div>
            </>
          )}
        </div>

        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.07] pt-2.5">
          <label className="flex items-center gap-2">
            <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/35">Pilot tag</span>
            <input
              className="field-tag"
              value={tag}
              maxLength={5}
              aria-label="Pilot tag for high scores"
              onChange={(e) => onTagChange(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5))}
            />
          </label>
          <div className="flex items-center gap-3">
            <button type="button" onClick={onOpenScores} className="link-btn" title="Solo hall only">
              HIGH SCORES
            </button>
            <button type="button" onClick={onOpenRules} className="link-btn">
              HOW TO PLAY
            </button>
          </div>
        </div>
        <p className="mt-2 text-left font-mono text-[8px] uppercase tracking-[0.14em] text-white/25" style={{ lineHeight: 1.6 }}>
          {local ? (
            <>
              Two seats · one keyboard · <span className="text-ember/80">2P never enters the hall</span>
            </>
          ) : (
            <>
              Personal best · <span className="text-acid/80">{formatScore(best)} pts</span>
            </>
          )}
        </p>
        {local && coarse && (
          <p className="mt-2 rounded-lg border border-ember/20 bg-ember/[0.07] px-2.5 py-2 text-left font-mono text-[8px] uppercase tracking-[0.12em] text-ember/80">
            2P needs a keyboard — P1 can also be steered by touch
          </p>
        )}
      </div>
    </div>
  );
}

function PauseOverlay({
  hud,
  onResume,
  onRestart,
  onQuit,
}: {
  hud: HudSnapshot;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
}) {
  const local = hud.mode === "local";
  return (
    <div className="absolute inset-0 z-20 grid place-items-center p-4">
      <div className="absolute inset-0 bg-[#040a08]/65 backdrop-blur-[3px]" />
      <div className="overlay-card relative w-full max-w-[380px] p-5 text-center sm:p-6">
        <div className="mx-auto mb-3 grid h-10 w-10 place-items-center rounded-xl border border-acid/25 bg-acid/10 text-acid">
          <PauseIcon className="h-4 w-4" />
        </div>
        <p className="eyebrow mb-1">Match on ice</p>
        <h2 className="display text-4xl text-white">PAUSED</h2>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {local ? (
            <>
              <div className="mini-stat">
                <span>P1</span>
                <strong className="text-acid">{hud.playerScore}</strong>
              </div>
              <div className="mini-stat">
                <span>P2</span>
                <strong className="text-ember">{hud.rivalScore}</strong>
              </div>
              <div className="mini-stat">
                <span>RALLY</span>
                <strong>{hud.bestRally}</strong>
              </div>
            </>
          ) : (
            <>
              <div className="mini-stat">
                <span>SCORE</span>
                <strong>{formatScore(hud.score)}</strong>
              </div>
              <div className="mini-stat">
                <span>COMBO</span>
                <strong className="text-acid">×{Math.max(hud.combo, 1)}</strong>
              </div>
              <div className="mini-stat">
                <span>RALLY</span>
                <strong>{hud.bestRally}</strong>
              </div>
            </>
          )}
        </div>
        <button type="button" onClick={onResume} className="btn btn-primary mt-4 w-full">
          <PlayIcon />
          RESUME
          <span className="ml-auto hidden font-mono text-[9px] opacity-55 sm:inline">SPACE</span>
        </button>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button type="button" onClick={onRestart} className="btn btn-secondary text-[11px]">
            <RestartIcon />
            RESTART
          </button>
          <button type="button" onClick={onQuit} className="btn btn-quiet text-[11px]">
            QUIT MATCH
          </button>
        </div>
        <p className="mt-3 font-mono text-[8px] uppercase tracking-[0.14em] text-white/25">R restart · SPACE resume</p>
      </div>
    </div>
  );
}

function GameOverOverlay({
  shell,
  tag,
  onRestart,
  onQuit,
  onOpenScores,
}: {
  shell: { result: RunResult } & RunRank;
  tag: string;
  onRestart: () => void;
  onQuit: () => void;
  onOpenScores: () => void;
}) {
  const { result, rank, isBest } = shell;
  const won = result.won;
  const local = result.mode === "local";
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center overflow-y-auto p-3 sm:p-4">
      <div className="fixed inset-0 bg-[#040a08]/78 backdrop-blur-[4px]" />
      <div className="overlay-card relative my-auto max-h-[calc(100dvh-1.5rem)] w-full max-w-[460px] overflow-y-auto p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="eyebrow mb-1">
              {local
                ? won
                  ? "P1 out-rallied P2"
                  : "P2 out-rallied P1"
                : won
                  ? "Machine outplayed"
                  : "The machine holds the line"}
            </p>
            <h2 className={`display text-[40px] leading-[0.9] sm:text-[48px] ${won ? "text-acid" : "text-ember"}`}>
              {local ? (won ? "P1 WINS." : "P2 WINS.") : won ? "VICTORY." : "GAME OVER."}
            </h2>
          </div>
          <span className={`chip ${won ? "chip-acid" : "chip-ember"} shrink-0`}>
            {local ? (won ? "P1" : "P2") : won ? "WON" : "LOST"}
          </span>
        </div>

        {local ? (
          <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2 rounded-2xl border border-white/[0.08] bg-black/20 px-4 py-3">
            <div className="text-left">
              <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-acid/80">P1 · {tag}</p>
              <p className="tnum text-[32px] font-semibold leading-tight text-acid">{result.playerScore}</p>
              <p className="tnum font-mono text-[8px] text-white/35">{formatScore(result.score)} pts</p>
            </div>
            <span className="display text-xl text-white/30">VS</span>
            <div className="text-right">
              <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-ember/80">P2</p>
              <p className="tnum text-[32px] font-semibold leading-tight text-ember">{result.rivalScore}</p>
              <p className="tnum font-mono text-[8px] text-white/35">{formatScore(result.p2Score)} pts</p>
            </div>
          </div>
        ) : (
          <div className="mt-4 flex items-end justify-between gap-3 rounded-2xl border border-white/[0.08] bg-black/20 px-4 py-3">
            <div>
              <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-white/35">Final score</p>
              <p className="tnum text-[34px] font-semibold leading-tight text-white sm:text-[40px]">
                {formatScore(result.score)}
              </p>
            </div>
            <div className="text-right">
              <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-white/35">Goals</p>
              <p className="tnum text-xl font-semibold text-white/85">
                {result.playerScore}
                <span className="mx-1 text-white/25">–</span>
                {result.rivalScore}
              </p>
            </div>
          </div>
        )}

        {local ? (
          <div className="mt-2 grid grid-cols-3 gap-2">
            <div className="mini-stat">
              <span>Max combo</span>
              <strong>
                <span className="text-acid">P1×{Math.max(result.bestCombo, 1)}</span>
                <span className="mx-1 text-white/20">·</span>
                <span className="text-ember">P2×{Math.max(result.bestComboP2, 1)}</span>
              </strong>
            </div>
            <div className="mini-stat">
              <span>Longest rally</span>
              <strong>{result.bestRally}</strong>
            </div>
            <div className="mini-stat">
              <span>Time</span>
              <strong>{formatDuration(result.duration)}</strong>
            </div>
          </div>
        ) : (
          <div className="mt-2 grid grid-cols-3 gap-2">
            <div className="mini-stat">
              <span>Best rally</span>
              <strong>{result.bestRally}</strong>
            </div>
            <div className="mini-stat">
              <span>Max combo</span>
              <strong className="text-acid">×{Math.max(result.bestCombo, 1)}</strong>
            </div>
            <div className="mini-stat">
              <span>Time</span>
              <strong>{formatDuration(result.duration)}</strong>
            </div>
          </div>
        )}

        <div className="mt-2.5 flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-2">
          {local ? (
            <div className="flex items-center gap-2.5">
              <span className="grid h-7 w-7 place-items-center rounded-md bg-ember/12 font-mono text-[9px] text-ember">2P</span>
              <div>
                <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/30">Local 2P</p>
                <p className="text-[11px] font-medium text-white/80">Not logged — the hall is solo</p>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2.5">
                <span className="grid h-7 w-7 place-items-center rounded-md bg-acid/12 font-mono text-[9px] text-acid">
                  {tag.slice(0, 3)}
                </span>
                <div>
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/30">Logged as</p>
                  <p className="text-[11px] font-medium text-white/80">{tag}</p>
                </div>
              </div>
              {rank > 0 ? (
                <div className="text-right">
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/30">
                    {isBest ? "New best" : "Local rank"}
                  </p>
                  <p className={`text-[12px] font-semibold ${isBest ? "text-acid" : "text-white/80"}`}>
                    {isBest ? "#1 ON THIS DEVICE" : `#${rank} ON THIS DEVICE`}
                  </p>
                </div>
              ) : (
                <p className="max-w-[120px] text-right font-mono text-[8px] uppercase tracking-[0.12em] text-white/30">
                  Keep rallying to make the board
                </p>
              )}
            </>
          )}
        </div>

        <button type="button" onClick={onRestart} className="btn btn-primary mt-3.5 w-full">
          <RestartIcon />
          RUN IT BACK
          <span className="ml-auto hidden font-mono text-[9px] opacity-55 sm:inline">ENTER / R</span>
        </button>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button type="button" onClick={onQuit} className="btn btn-secondary text-[11px]">
            BACK TO LOBBY
          </button>
          <button type="button" onClick={onOpenScores} className="btn btn-quiet text-[11px]">
            HIGH SCORES
          </button>
        </div>
      </div>
    </div>
  );
}

export default function GameStage({
  best,
  tag,
  muted,
  suspended,
  onTagChange,
  onRunEnd,
  onOpenRules,
  onOpenScores,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<NeonRallyEngine | null>(null);
  const sfxRef = useRef<Sfx | null>(null);
  const runEndRef = useRef(onRunEnd);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [result, setResult] = useState<({ result: RunResult } & RunRank) | null>(null);
  const [mode, setMode] = useState<GameMode>(() => loadMode());
  const [difficulty, setDifficulty] = useState<Difficulty>(() => loadDifficulty());
  const [coarse, setCoarse] = useState(false);

  runEndRef.current = onRunEnd;

  useEffect(() => {
    setCoarse(window.matchMedia("(pointer: coarse)").matches);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(MODE_KEY, mode);
    } catch {
      /* noop */
    }
  }, [mode]);

  useEffect(() => {
    try {
      localStorage.setItem(DIFFICULTY_KEY, difficulty);
    } catch {
      /* noop */
    }
  }, [difficulty]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const sfx = new Sfx();
    sfx.setMuted(muted);
    sfxRef.current = sfx;
    const engine = new NeonRallyEngine(
      canvas,
      {
        onHud: (next) => setHud(next),
        onGameOver: (run) => {
          const meta = runEndRef.current(run);
          setResult({ result: run, ...meta });
        },
      },
      sfx,
    );
    engineRef.current = engine;

    const onVisibility = () => {
      if (document.hidden && engine.getStatus() === "playing") engine.pause();
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      engine.destroy();
      sfx.dispose();
      engineRef.current = null;
      sfxRef.current = null;
    };
    // Engine must only be created once; callbacks are kept fresh through refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    sfxRef.current?.setMuted(muted);
  }, [muted]);

  useEffect(() => {
    if (suspended) engineRef.current?.pause();
  }, [suspended]);

  const startGame = () => {
    setResult(null);
    sfxRef.current?.unlock();
    engineRef.current?.start(mode, difficulty);
    if (window.matchMedia("(max-width: 1023px)").matches) {
      requestAnimationFrame(() => document.getElementById("arena")?.scrollIntoView({ behavior: "smooth", block: "start" }));
    }
  };

  const pauseGame = () => {
    engineRef.current?.pause();
  };

  const resumeGame = () => {
    engineRef.current?.resume();
  };

  const quitGame = () => {
    setResult(null);
    engineRef.current?.quitToMenu();
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
      if (suspended) return;
      const engine = engineRef.current;
      if (!engine) return;
      const status = engine.getStatus();

      if (e.code === "Enter") {
        if (status === "attract" || status === "gameover") {
          e.preventDefault();
          startGame();
        } else if (status === "paused") {
          e.preventDefault();
          resumeGame();
        }
      } else if (e.code === "Space") {
        if (status === "attract") {
          e.preventDefault();
          startGame();
        } else if (status === "playing" || status === "paused") {
          e.preventDefault();
          engine.togglePause();
        } else if (status === "gameover") {
          e.preventDefault();
          startGame();
        }
      } else if (e.code === "Escape" || e.code === "KeyP") {
        if (status === "playing" || status === "paused") {
          e.preventDefault();
          engine.togglePause();
        } else if (status === "gameover") {
          e.preventDefault();
          quitGame();
        }
      } else if (e.code === "KeyR") {
        if (status !== "attract") {
          e.preventDefault();
          startGame();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // Handlers only touch refs and state setters.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [suspended, mode]);

  const live = hud.status === "playing" || hud.status === "paused";
  const displayMode = hud.status === "attract" ? mode : hud.mode;
  const local = displayMode === "local";
  const combo = hud.lastSide === 2 ? hud.comboP2 : hud.combo;
  const surgeReady = local ? hud.surge >= 100 || hud.surgeP2 >= 100 : hud.surge >= 100;
  const surgeLabelReady = (side: "p1" | "p2") => (side === "p1" ? hud.surge : hud.surgeP2) >= 100;
  const hasEffects = hud.wide > 0 || hud.slow > 0 || hud.shield || hud.wideP2 > 0 || hud.shieldP2 || hud.stagger > 0;

  return (
    <section className="panel overflow-hidden">
      {/* Scoreboard */}
      <div className="relative flex items-center justify-between gap-2 border-b border-white/[0.07] px-3 py-2.5 sm:px-5 sm:py-3">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-acid/30 to-transparent" />
        <TeamScore
          side="player"
          score={hud.playerScore}
          label={local ? "P1" : "YOU"}
          sub={local ? "LOCAL" : "SOLO"}
        />

        <div className="flex min-w-[86px] flex-col items-center text-center sm:min-w-[150px]">
          <div className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.14em] text-white/35 sm:text-[9px]">
            <span className={`status-dot ${STATUS_LABEL[hud.status] === "LIVE" ? "status-dot-live" : ""}`} />
            {STATUS_LABEL[hud.status]} · {formatDuration(hud.time)}
          </div>
          <p className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.18em] text-white/25">
            {local ? "2P SEATS" : "FIRST TO 7"}
          </p>
          {!local && (
            <p className="tnum mt-1 text-[11px] font-medium text-white/70 sm:text-[13px]">
              {formatScore(hud.score)} <span className="font-mono text-[8px] uppercase tracking-wider text-white/30">pts</span>
            </p>
          )}
        </div>

        <TeamScore
          side="rival"
          score={hud.rivalScore}
          label={local ? "P2" : "RIVAL"}
          sub={local ? "LOCAL" : "MACHINE"}
        />
      </div>

      {/* Arena */}
      <div className="relative isolate">
        <div className="arena-frame relative h-[clamp(330px,51vh,520px)] w-full overflow-hidden bg-[#081210] sm:h-[clamp(360px,52vh,540px)]">
          <canvas ref={canvasRef} className="block h-full w-full" aria-label="Neon Rally game arena" role="img" />

          {live && (
            <div className="pointer-events-none absolute inset-0 z-10">
              <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5 sm:left-4 sm:top-4">
                {local ? (
                  <>
                    {combo >= 2 && (
                      <span key={`${hud.lastSide}-${combo}`} className={`combo-pill ${hud.lastSide === 2 ? "border-ember/40! bg-ember/12! text-ember!" : ""}`}>
                        <span className="mr-1 text-[9px] tracking-[0.14em] opacity-60">P{hud.lastSide}</span>×{combo}
                        <span className="ml-1 text-[8px] tracking-[0.16em] opacity-60">COMBO</span>
                      </span>
                    )}
                    {hud.lastSide === 1 && hud.rally > 0 && combo < 2 && (
                      <span className="hud-chip">
                        <span className="text-white/35">RALLY</span>
                        <span className="tnum text-white/90">{hud.rally}</span>
                      </span>
                    )}
                  </>
                ) : (
                  <>
                    {combo >= 2 ? (
                      <span key={combo} className="combo-pill">
                        <span className="text-[10px] text-acid/60">×</span>
                        {combo}
                        <span className="ml-1 text-[8px] tracking-[0.16em] text-acid/60">COMBO</span>
                      </span>
                    ) : hud.rally > 0 ? (
                      <span className="hud-chip">
                        <span className="text-white/35">RALLY</span>
                        <span className="tnum text-white/90">{hud.rally}</span>
                      </span>
                    ) : null}
                  </>
                )}
              </div>

              <div className="absolute right-3 top-3 flex flex-col items-end gap-1.5 sm:right-4 sm:top-4">
                <span className="hud-chip">
                  <span className="text-white/35">{local ? "MODE" : "LVL"}</span>
                  <span className="tnum text-white/90">{local ? "2P" : String(hud.level).padStart(2, "0")}</span>
                </span>
                {surgeReady && (
                  <span className="combo-pill border-ember/40 bg-ember/12 text-ember">
                    <svg viewBox="0 0 12 12" className="h-2.5 w-2.5" fill="currentColor" aria-hidden="true">
                      <path d="M6.8.5 2 7h2.7l-1 4.5L9.5 5H6.6L6.8.5Z" />
                    </svg>
                    SURGE READY
                  </span>
                )}
              </div>

              {hasEffects && (
                <div className="absolute bottom-3 left-3 flex flex-wrap gap-1.5 sm:left-4">
                  {hud.shield && <span className="effect-chip border-violet/40 text-violet">P1 SHIELD</span>}
                  {hud.wide > 0 && <span className="effect-chip border-acid/40 text-acid">P1 WIDE {Math.ceil(hud.wide)}s</span>}
                  {hud.shieldP2 && <span className="effect-chip border-violet/40 text-violet">P2 SHIELD</span>}
                  {hud.wideP2 > 0 && <span className="effect-chip border-ember/40 text-ember">P2 WIDE {Math.ceil(hud.wideP2)}s</span>}
                  {hud.slow > 0 && <span className="effect-chip border-aqua/40 text-aqua">SLO-MO {Math.ceil(hud.slow)}s</span>}
                  {hud.stagger > 0 && hud.staggerSide && (
                    <span className="effect-chip border-[#8be1ff]/40 text-[#8be1ff]">
                      {hud.staggerSide === "p1" ? "P1" : "P2"} STAGGERED {Math.ceil(hud.stagger)}s
                    </span>
                  )}
                </div>
              )}

              {coarse && hud.status === "playing" && hud.time < 6 && (
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 animate-[fade-in_.5s_ease-out] rounded-full border border-white/10 bg-black/45 px-3 py-1.5 font-mono text-[8px] uppercase tracking-[0.16em] text-white/55 backdrop-blur-sm">
                  {local ? "P1 steers by touch" : "Drag up / down to defend"}
                </div>
              )}
            </div>
          )}

          {hud.status === "playing" && (
            <button
              type="button"
              onClick={pauseGame}
              aria-label="Pause match"
              className="absolute bottom-3 right-3 z-10 grid h-9 w-9 place-items-center rounded-full border border-white/12 bg-black/45 text-white/70 backdrop-blur-md transition hover:border-acid/40 hover:text-acid sm:right-4"
            >
              <PauseIcon className="h-3 w-3" />
            </button>
          )}

          {hud.status === "attract" && (
            <MenuOverlay
              mode={mode}
              onModeChange={setMode}
              difficulty={difficulty}
              onDifficultyChange={setDifficulty}
              best={best}
              tag={tag}
              coarse={coarse}
              onTagChange={onTagChange}
              onStart={startGame}
              onOpenRules={onOpenRules}
              onOpenScores={onOpenScores}
            />
          )}

          {hud.status === "paused" && (
            <PauseOverlay hud={hud} onResume={resumeGame} onRestart={startGame} onQuit={quitGame} />
          )}

          {hud.status === "gameover" && result && (
            <GameOverOverlay
              shell={result}
              tag={tag || "ACE"}
              onRestart={startGame}
              onQuit={quitGame}
              onOpenScores={onOpenScores}
            />
          )}
        </div>
      </div>

      {/* Telemetry */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-white/[0.07] bg-black/15 px-3 py-2.5 sm:px-4">
        <div className="flex items-center gap-2">
          <span className={`status-dot ${hud.status === "playing" ? "status-dot-live" : ""}`} />
          <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/40">
            {hud.status === "playing" ? "Match live" : hud.status === "paused" ? "Frozen" : hud.status === "gameover" ? "Match final" : "Awaiting serve"}
          </span>
        </div>

        <div className="hidden h-3 w-px bg-white/10 sm:block" />

        <div className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.12em] text-white/35">
          <span>Rally</span>
          <span className="tnum text-[10px] text-white/75">{hud.rally}</span>
        </div>

        {local ? (
          <div className="flex min-w-[180px] flex-1 items-center gap-2">
            <div className="flex flex-1 items-center gap-1.5">
              <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-acid/70">P1</span>
              <div className="surge-track !h-1.5" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={hud.surge} aria-label="P1 surge">
                <div className={`surge-fill ${surgeLabelReady("p1") ? "surge-fill-ready" : ""}`} style={{ width: `${Math.max(0, Math.min(100, hud.surge))}%` }} />
              </div>
              <span className={`tnum font-mono text-[8px] ${surgeLabelReady("p1") ? "text-ember" : "text-white/35"}`}>
                {surgeLabelReady("p1") ? "MAX" : `${hud.surge}%`}
              </span>
            </div>
            <div className="flex flex-1 items-center gap-1.5">
              <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-ember/70">P2</span>
              <div className="surge-track !h-1.5" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={hud.surgeP2} aria-label="P2 surge">
                <div className={`surge-fill ${surgeLabelReady("p2") ? "surge-fill-ready" : ""}`} style={{ width: `${Math.max(0, Math.min(100, hud.surgeP2))}%` }} />
              </div>
              <span className={`tnum font-mono text-[8px] ${surgeLabelReady("p2") ? "text-ember" : "text-white/35"}`}>
                {surgeLabelReady("p2") ? "MAX" : `${hud.surgeP2}%`}
              </span>
            </div>
          </div>
        ) : (
          <div className="flex min-w-[120px] flex-1 items-center gap-2">
            <div className="flex items-center gap-1 font-mono text-[8px] uppercase tracking-[0.12em] text-white/35">
              <svg viewBox="0 0 12 12" className={`h-2.5 w-2.5 ${hud.surge >= 100 ? "text-ember" : "text-white/25"}`} fill="currentColor" aria-hidden="true">
                <path d="M6.8.5 2 7h2.7l-1 4.5L9.5 5H6.6L6.8.5Z" />
              </svg>
              Surge
            </div>
            <div
              className="surge-track"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={hud.surge}
              aria-label="Surge charge"
            >
              <div
                className={`surge-fill ${hud.surge >= 100 ? "surge-fill-ready" : ""}`}
                style={{ width: `${Math.max(0, Math.min(100, hud.surge))}%` }}
              />
            </div>
            <span className={`tnum font-mono text-[8px] ${hud.surge >= 100 ? "text-ember" : "text-white/35"}`}>
              {hud.surge >= 100 ? "MAX" : `${hud.surge}%`}
            </span>
          </div>
        )}

        <div className="ml-auto flex items-center gap-1">
          <button
            type="button"
            onClick={() => engineRef.current?.togglePause()}
            disabled={hud.status !== "playing" && hud.status !== "paused"}
            className="icon-button"
            aria-label={hud.status === "paused" ? "Resume match" : "Pause match"}
          >
            {hud.status === "paused" ? <PlayIcon className="h-3.5 w-3.5" /> : <PauseIcon className="h-3.5 w-3.5" />}
          </button>
          <button
            type="button"
            onClick={startGame}
            disabled={hud.status === "attract"}
            className="icon-button"
            aria-label="Restart match"
          >
            <RestartIcon className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
}
