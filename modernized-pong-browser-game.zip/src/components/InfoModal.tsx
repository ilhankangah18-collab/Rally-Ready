import { useEffect } from "react";
import { formatScore, type ScoreEntry } from "../game/storage";
import { POWER_ITEMS, PowerGlyph, ScoreTable } from "./SideRail";

export type InfoMode = "rules" | "scores" | null;

function CloseIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" className={className} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
      <path d="m4 4 8 8M12 4l-8 8" />
    </svg>
  );
}

function MiniKey({ children }: { children: React.ReactNode }) {
  return <kbd className="keycap !min-w-[20px] !px-1.5 !py-0.5 !text-[9px]">{children}</kbd>;
}

export default function InfoModal({
  mode,
  onClose,
  onSwitch,
  scores,
  highlightId,
  best,
}: {
  mode: InfoMode;
  onClose: () => void;
  onSwitch: (mode: "rules" | "scores") => void;
  scores: ScoreEntry[];
  highlightId: string | null;
  best: number;
}) {
  useEffect(() => {
    if (!mode) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Escape") {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [mode, onClose]);

  if (!mode) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-[#030807]/80 p-3 backdrop-blur-md sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={mode === "rules" ? "How to play" : "High scores"}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal-card relative my-auto w-full max-w-[640px] animate-[overlay-in_.22s_ease-out]">
        <div className="flex items-center justify-between gap-3 border-b border-white/[0.07] px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2.5">
            <div className="logo-mark h-8 w-8">
              <span className="logo-bar left-[6px]" />
              <span className="logo-bar right-[6px]" />
              <span className="logo-ball" />
            </div>
            <div>
              <p className="text-[12px] font-semibold tracking-wider text-white/90">NEON RALLY</p>
              <p className="font-mono text-[7px] uppercase tracking-[0.18em] text-white/30">Arcade field manual</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="icon-button !h-8 !w-8" aria-label="Close">
            <CloseIcon className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="flex gap-1 border-b border-white/[0.07] px-3 pt-2 sm:px-4">
          <button
            type="button"
            onClick={() => onSwitch("rules")}
            className={`tab-button ${mode === "rules" ? "tab-button-active" : ""}`}
          >
            How to play
          </button>
          <button
            type="button"
            onClick={() => onSwitch("scores")}
            className={`tab-button ${mode === "scores" ? "tab-button-active" : ""}`}
          >
            High scores
          </button>
        </div>

        <div className="max-h-[calc(100dvh-170px)] overflow-y-auto p-4 sm:p-5">
          {mode === "rules" ? (
            <div>
              <div className="rounded-xl border border-acid/15 bg-acid/[0.045] p-3.5">
                <p className="eyebrow mb-1">The objective</p>
                <h3 className="text-xl font-semibold leading-tight text-white">
                  First to seven goals. <span className="text-acid">Points are forever.</span>
                </h3>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-white/50">
                  Every return builds your combo and your score. The machine learns as the match unfolds, so move the
                  paddle before the ball arrives — and attack with the edges.
                </p>
              </div>

              <div className="mt-3 grid gap-2 sm:grid-cols-3">
                <div className="rule-tile">
                  <span className="rule-index">01</span>
                  <p className="rule-title">Stack the combo</p>
                  <p className="rule-copy">Each return adds 20 × your current combo. A miss resets it to zero.</p>
                </div>
                <div className="rule-tile">
                  <span className="rule-index">02</span>
                  <p className="rule-title">Bank the surge</p>
                  <p className="rule-copy">Returns fill the surge gauge. At 100, your next hit becomes a 1.5× power shot.</p>
                </div>
                <div className="rule-tile">
                  <span className="rule-index">03</span>
                  <p className="rule-title">Chase the orbs</p>
                  <p className="rule-copy">Collect buffs with your paddle. They drift, they vanish, they're worth it.</p>
                </div>
              </div>

              <h3 className="mb-2 mt-4 font-mono text-[8px] uppercase tracking-[0.2em] text-white/30">Controls</h3>
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2">
                  <span className="text-[11px] text-white/55">Move paddle</span>
                  <span className="flex items-center gap-1">
                    <MiniKey>W</MiniKey>
                    <MiniKey>S</MiniKey>
                    <span className="px-0.5 font-mono text-[8px] text-white/25">/</span>
                    <MiniKey>
                      <svg viewBox="0 0 10 10" className="h-2 w-2" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M5 8.3V1.7M2.2 4.5 5 1.7l2.8 2.8" />
                      </svg>
                    </MiniKey>
                    <MiniKey>
                      <svg viewBox="0 0 10 10" className="h-2 w-2" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M5 1.7v6.6M7.8 5.5 5 8.3 2.2 5.5" />
                      </svg>
                    </MiniKey>
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2">
                  <span className="text-[11px] text-white/55">Steer</span>
                  <span className="flex items-center gap-1">
                    <MiniKey>MOUSE</MiniKey>
                    <MiniKey>TOUCH</MiniKey>
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2">
                  <span className="text-[11px] text-white/55">Pause / resume</span>
                  <span className="flex items-center gap-1">
                    <MiniKey>SPACE</MiniKey>
                    <MiniKey>ESC</MiniKey>
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2">
                  <span className="text-[11px] text-white/55">Restart instantly</span>
                  <span className="flex items-center gap-1">
                    <MiniKey>R</MiniKey>
                    <MiniKey>ENTER</MiniKey>
                  </span>
                </div>
              </div>

              <h3 className="mb-2 mt-4 font-mono text-[8px] uppercase tracking-[0.2em] text-white/30">
                Collectible drops
              </h3>
              <div className="grid gap-1.5 sm:grid-cols-2">
                {POWER_ITEMS.map((item) => (
                  <div
                    key={item.type}
                    className="flex items-center gap-2.5 rounded-lg border border-white/[0.06] bg-white/[0.018] px-2.5 py-2"
                  >
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-md border"
                      style={{ color: item.color, borderColor: `${item.color}33`, background: `${item.color}0f` }}
                    >
                      <PowerGlyph type={item.type} className="h-3.5 w-3.5" />
                    </span>
                    <div>
                      <p className="text-[10.5px] font-semibold text-white/80">{item.name}</p>
                      <p className="text-[9.5px] leading-snug text-white/38">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-3 rounded-lg border border-acid/15 bg-acid/[0.045] px-3 py-2.5 text-[10.5px] leading-relaxed text-white/55">
                <p className="font-mono text-[8px] uppercase tracking-[0.18em] text-acid/80">Local 2-player</p>
                <p className="mt-1 text-[11px] leading-relaxed text-white/65">
                  Two seats, one keyboard. P1: <span className="text-acid">W / S</span> (and mouse / touch steering) —
                  P2: <span className="text-ember">↑ / ↓</span> arrow keys. Power-ups, surge shots and the hall-agnostic
                  results screen behave identically. <span className="text-white/40">2P never enters the hall of fame.</span>
                </p>
              </div>
              <div className="mt-2 rounded-lg border border-ember/15 bg-ember/[0.045] px-3 py-2.5 text-[10.5px] leading-relaxed text-white/45">
                <span className="font-semibold text-ember">Pro tip —</span> hitting with the paddle's edge changes the
                return angle. Aim your body, not just the ball. Goals earn +500, surge shots +750, rallies of 10+
                and speed goals count extra. One <span className="text-[#8be1ff]">Stagger</span> orb lands per match.
              </div>
            </div>
          ) : (
            <div>
              <div className="mb-3 flex items-end justify-between rounded-xl border border-white/[0.07] bg-white/[0.025] px-3.5 py-3">
                <div>
                  <p className="eyebrow mb-1">Personal best</p>
                  <p className="tnum text-[30px] font-semibold leading-none text-acid">{formatScore(best)}</p>
                  <p className="mt-1 font-mono text-[7.5px] uppercase tracking-[0.16em] text-white/25">
                    Points · saved locally
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[8px] uppercase tracking-[0.16em] text-white/25">Hall of fame</p>
                  <p className="text-[12px] font-semibold text-white/75">{scores.length} runs</p>
                  <p className="mt-0.5 font-mono text-[7.5px] uppercase tracking-[0.14em] text-white/22">
                    This browser only
                  </p>
                </div>
              </div>
              <div className="rounded-xl border border-white/[0.07] bg-black/15 p-2">
                <ScoreTable scores={scores} highlightId={highlightId} rows={8} showBest />
              </div>
              <p className="mt-2.5 px-1 text-[10px] leading-relaxed text-white/30">
                Scores are attached to your pilot tag and stored in this browser. No account, no cloud, no waiting.
              </p>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-white/[0.07] px-4 py-2.5">
          <span className="font-mono text-[7.5px] uppercase tracking-[0.16em] text-white/22">Neon Rally · solo arcade</span>
          <button type="button" onClick={onClose} className="btn btn-secondary !min-h-0 !px-3 !py-1.5 !text-[10px]">
            GOT IT
          </button>
        </div>
      </div>
    </div>
  );
}
