import { useEffect, useRef, useState } from "react";
import GameStage from "./components/GameStage";
import InfoModal, { type InfoMode } from "./components/InfoModal";
import { Leaderboard, PlayerCard, PowerUps } from "./components/SideRail";
import type { RunResult } from "./game/engine";
import {
  formatScore,
  loadMuted,
  loadScores,
  loadTag,
  makeId,
  saveMuted,
  saveScores,
  saveTag,
  type ScoreEntry,
} from "./game/storage";

function VolumeIcon({ muted, className = "h-4 w-4" }: { muted: boolean; className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3.5 7.5h2.6L10 4.2v11.6l-3.9-3.3H3.5v-5Z" />
      {muted ? (
        <path d="m13 7 4 4M17 7l-4 4" />
      ) : (
        <path d="M13 6.4a4.2 4.2 0 0 1 0 7.2M15.3 4.2a7.2 7.2 0 0 1 0 11.6" />
      )}
    </svg>
  );
}

function ExpandIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M7.2 3.2H3.2v4M12.8 3.2h4v4M7.2 16.8H3.2v-4M12.8 16.8h4v-4" />
    </svg>
  );
}

function ArrowUpRight({ className = "h-3 w-3" }: { className?: string }) {
  return (
    <svg viewBox="0 0 12 12" className={className} fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 9.5 9.5 2.5M4 2.5h5.5V8" />
    </svg>
  );
}

export default function App() {
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const scoresRef = useRef(scores);
  scoresRef.current = scores;
  const [tag, setTag] = useState<string>(() => loadTag());
  const [muted, setMuted] = useState<boolean>(() => loadMuted());
  const [modal, setModal] = useState<InfoMode>(null);
  const [newId, setNewId] = useState<string | null>(null);
  const [isFull, setIsFull] = useState(false);

  const best = scores[0]?.score ?? 0;

  useEffect(() => {
    const onChange = () => setIsFull(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, [modal]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
      if (e.code === "KeyM") {
        setMuted((current) => {
          const next = !current;
          saveMuted(next);
          return next;
        });
      } else if (e.code === "Escape" && modal !== null) {
        setModal(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modal]);

  const handleTagChange = (next: string) => {
    const clean = next.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
    setTag(clean);
    if (clean.length >= 2) saveTag(clean);
  };

  const handleRunEnd = (result: RunResult) => {
    const previousBest = scoresRef.current[0]?.score ?? 0;
    if (result.mode === "local") {
      return { rank: 0, isBest: false, best: previousBest };
    }
    if (result.score <= 0) {
      return { rank: 0, isBest: false, best: previousBest };
    }
    const entry: ScoreEntry = {
      id: makeId(),
      tag: (tag || "ACE").slice(0, 5),
      score: result.score,
      rally: result.bestRally,
      bestCombo: result.bestCombo,
      goals: `${result.playerScore}–${result.rivalScore}`,
      won: result.won,
      date: Date.now(),
    };
    const next = [...scoresRef.current, entry]
      .sort((a, b) => b.score - a.score || b.date - a.date)
      .slice(0, 8);
    scoresRef.current = next;
    setScores(next);
    saveScores(next);
    const rank = next.findIndex((s) => s.id === entry.id) + 1;
    setNewId(rank > 0 ? entry.id : null);
    return {
      rank,
      isBest: entry.score > previousBest,
      best: Math.max(previousBest, entry.score),
    };
  };

  const toggleMute = () => {
    setMuted((current) => {
      const next = !current;
      saveMuted(next);
      return next;
    });
  };

  const toggleFull = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      /* iOS and embedded frames can decline fullscreen */
    }
  };

  const scrollToArena = () => {
    document.getElementById("arena")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const openModal = (mode: "rules" | "scores") => setModal(mode);

  return (
    <div className="site-shell">
      <div className="site-backdrop" aria-hidden="true">
        <div className="ambient ambient-acid" />
        <div className="ambient ambient-ember" />
        <div className="site-grid" />
        <div className="site-noise" />
      </div>

      <div className="relative z-10 flex min-h-screen flex-col">
        <header className="mx-auto w-full max-w-[1480px] px-4 pb-3 pt-4 sm:px-6 sm:pb-4 sm:pt-5 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="group flex items-center gap-2.5 text-left" aria-label="Neon Rally home">
              <div className="logo-mark h-9 w-9 transition-transform duration-300 group-hover:-rotate-3">
                <span className="logo-bar left-[7px]" />
                <span className="logo-bar right-[7px]" />
                <span className="logo-ball" />
              </div>
              <div>
                <p className="text-[14px] font-bold leading-none tracking-[0.13em] text-white">
                  RALLY<span className="text-acid">//</span>
                </p>
                <p className="mt-1 font-mono text-[6.5px] uppercase tracking-[0.26em] text-white/30">Neon arcade</p>
              </div>
            </button>

            <nav className="hidden items-center gap-0.5 rounded-full border border-white/[0.07] bg-white/[0.025] p-1 md:flex" aria-label="Main navigation">
              <button
                type="button"
                onClick={scrollToArena}
                className="flex items-center gap-1.5 rounded-full bg-white/[0.06] px-3.5 py-1.5 text-[10px] font-medium uppercase tracking-[0.12em] text-white/90 transition hover:bg-white/[0.09]"
              >
                <span className="h-1 w-1 rounded-full bg-acid" />
                Arena
              </button>
              <button
                type="button"
                onClick={() => openModal("scores")}
                className="rounded-full px-3.5 py-1.5 text-[10px] font-medium uppercase tracking-[0.12em] text-white/40 transition hover:text-white/80"
              >
                Leaderboard
              </button>
              <button
                type="button"
                onClick={() => openModal("rules")}
                className="rounded-full px-3.5 py-1.5 text-[10px] font-medium uppercase tracking-[0.12em] text-white/40 transition hover:text-white/80"
              >
                How to play
              </button>
            </nav>

            <div className="flex items-center gap-1.5">
              <div className="mr-1 hidden items-center gap-2 rounded-full border border-white/[0.06] bg-black/20 px-2.5 py-1.5 lg:flex">
                <span className="status-dot status-dot-live" />
                <span className="font-mono text-[7.5px] uppercase tracking-[0.16em] text-white/35">System online</span>
              </div>
              <button
                type="button"
                onClick={toggleMute}
                className="icon-button !h-9 !w-9"
                aria-label={muted ? "Unmute sound" : "Mute sound"}
                title={`${muted ? "Unmute" : "Mute"} sound (M)`}
              >
                <VolumeIcon muted={muted} />
              </button>
              <button
                type="button"
                onClick={toggleFull}
                className="icon-button !h-9 !w-9"
                aria-label={isFull ? "Exit fullscreen" : "Enter fullscreen"}
                title="Fullscreen"
              >
                <ExpandIcon />
              </button>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1480px] flex-1 px-4 pb-8 sm:px-6 lg:px-8">
          <div className="mb-4 flex items-end justify-between gap-6 sm:mb-5">
            <div>
              <div className="mb-2 flex items-center gap-2 font-mono text-[8px] uppercase tracking-[0.2em] text-white/30">
                <span className="h-px w-5 bg-acid/50" />
                Arcade / Solo circuit
                <span className="hidden text-white/15 sm:inline">— No. 001</span>
              </div>
              <h1 className="display text-[38px] leading-[0.85] tracking-[-0.045em] text-white sm:text-[50px] lg:text-[58px]">
                NEON <span className="text-acid">RALLY</span>
                <span className="text-acid">.</span>
              </h1>
            </div>
            <div className="hidden flex-col items-end gap-2 lg:flex">
              <p className="max-w-[310px] text-right text-[11px] leading-relaxed text-white/38">
                Classic physics, new rules. <span className="text-white/75">Chain returns, bank the surge</span> and
                send the machine home early.
              </p>
              <div className="flex items-center gap-1.5">
                <span className="chip">
                  <span className="text-white/25">BEST</span>
                  <span className="tnum text-acid">{formatScore(best)}</span>
                </span>
                <span className="chip hidden lg:inline-flex">
                  <span className="h-1 w-1 rounded-full bg-white/30" />
                  FIRST TO 7
                </span>
                <button type="button" onClick={() => openModal("rules")} className="link-btn !text-[8px]">
                  RULES <ArrowUpRight />
                </button>
              </div>
            </div>
          </div>

          <div id="arena" className="grid items-start gap-3.5 scroll-mt-3 lg:grid-cols-[minmax(0,1fr)_342px] xl:grid-cols-[minmax(0,1fr)_356px]">
            <GameStage
              best={best}
              tag={tag}
              muted={muted}
              suspended={modal !== null}
              onTagChange={handleTagChange}
              onRunEnd={handleRunEnd}
              onOpenRules={() => openModal("rules")}
              onOpenScores={() => openModal("scores")}
            />

            <aside className="flex min-w-0 flex-col gap-3">
              <div className="flex items-center justify-between px-1">
                <span className="eyebrow">The circuit</span>
                <span className="font-mono text-[7px] uppercase tracking-[0.16em] text-white/22">Season 01 · local</span>
              </div>
              <PlayerCard tag={tag} best={best} scores={scores} onTagChange={handleTagChange} />
              <Leaderboard scores={scores} highlightId={newId} onOpenAll={() => openModal("scores")} />
              <PowerUps />
            </aside>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/[0.055] bg-white/[0.018] px-3.5 py-2.5">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 font-mono text-[7.5px] uppercase tracking-[0.13em] text-white/27">
              <span className="flex items-center gap-1.5">
                <kbd className="keycap !min-w-0 !px-1 !py-0.5 !text-[7px]">W</kbd>
                <kbd className="keycap !min-w-0 !px-1 !py-0.5 !text-[7px]">S</kbd>
                Move
              </span>
              <span className="flex items-center gap-1.5">
                <kbd className="keycap !min-w-0 !px-1 !py-0.5 !text-[7px]">SPACE</kbd>
                Pause
              </span>
              <span className="flex items-center gap-1.5">
                <kbd className="keycap !min-w-0 !px-1 !py-0.5 !text-[7px]">R</kbd>
                Restart
              </span>
              <span className="hidden items-center gap-1.5 sm:flex">
                <kbd className="keycap !min-w-0 !px-1 !py-0.5 !text-[7px]">M</kbd>
                Sound
              </span>
            </div>
            <p className="font-mono text-[7px] uppercase tracking-[0.13em] text-white/20">
              Touch ready · 60 fps loop · zero downloads
            </p>
          </div>
        </main>

        <footer className="mx-auto w-full max-w-[1480px] px-4 pb-5 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.06] pt-4">
            <div className="flex items-center gap-2">
              <div className="logo-mark h-5 w-5 !rounded-[6px]">
                <span className="logo-bar !bottom-[4px] !left-[3.5px] !top-[4px] !w-[2px]" />
                <span className="logo-bar !bottom-[4px] !right-[3.5px] !top-[4px] !w-[2px]" />
                <span className="logo-ball !h-1 !w-1" />
              </div>
              <span className="font-mono text-[7.5px] uppercase tracking-[0.16em] text-white/25">
                NO LOGINS. NO LAG. JUST RALLY.
              </span>
            </div>
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => openModal("rules")} className="link-btn !text-[7.5px]">
                HOW TO PLAY
              </button>
              <button type="button" onClick={() => openModal("scores")} className="link-btn !text-[7.5px]">
                LOCAL SCORES
              </button>
              <button type="button" onClick={toggleMute} className="link-btn !text-[7.5px]" aria-label={muted ? "Unmute" : "Mute"}>
                <VolumeIcon muted={muted} className="h-2.5 w-2.5" />
                {muted ? "MUTED" : "SOUND ON"}
              </button>
            </div>
          </div>
        </footer>
      </div>

      <InfoModal
        mode={modal}
        onClose={() => setModal(null)}
        onSwitch={(mode) => setModal(mode)}
        scores={scores}
        highlightId={newId}
        best={best}
      />
    </div>
  );
}
