import type { Sfx } from "./audio";

export type GameStatus = "attract" | "playing" | "paused" | "gameover";
export type GameMode = "solo" | "local";
export type Difficulty = "casual" | "classic" | "ranked";
export type PowerType = "wide" | "slow" | "shield" | "surge" | "stagger";

export const DIFFICULTY_TABLE: Record<
  Difficulty,
  { aiSpeedBase: number; aiSpeedPerLvl: number; err: number; errRefresh: number; retain: number; lvlTime: number; lvlScore: number; speedScale: number }
> = {
  casual: { aiSpeedBase: 0.46, aiSpeedPerLvl: 0.055, err: 1.0, errRefresh: 0.85, retain: 0.3, lvlTime: 78, lvlScore: 6, speedScale: 0.94 },
  classic: { aiSpeedBase: 0.58, aiSpeedPerLvl: 0.075, err: 1.0, errRefresh: 0.52, retain: 0.42, lvlTime: 55, lvlScore: 4, speedScale: 1.0 },
  ranked: { aiSpeedBase: 0.7, aiSpeedPerLvl: 0.11, err: 0.7, errRefresh: 0.36, retain: 0.52, lvlTime: 40, lvlScore: 3, speedScale: 1.07 },
};

export interface HudSnapshot {
  status: GameStatus;
  mode: GameMode;
  playerScore: number;
  rivalScore: number;
  score: number; // P1 points
  p2Score: number; // P2 points
  combo: number; // P1 combo
  comboP2: number; // P2 combo
  lastSide: 1 | 2;
  bestCombo: number;
  bestComboP2: number;
  rally: number;
  bestRally: number;
  surge: number; // P1
  surgeP2: number; // P2
  shield: boolean; // P1
  shieldP2: boolean; // P2
  wide: number; // P1
  wideP2: number; // P2
  slow: number; // shared
  time: number;
  fps: number;
  level: number;
  winner: "player" | "rival" | null;
  staggerSide: "p1" | "p2" | null;
  stagger: number;
}

export interface RunResult {
  mode: GameMode;
  score: number; // P1 points
  p2Score: number; // P2 points
  playerScore: number; // P1 goals
  rivalScore: number; // P2 goals
  bestRally: number;
  bestCombo: number;
  bestComboP2: number;
  duration: number;
  hits: number;
  won: boolean; // P1 won
}

interface EngineCallbacks {
  onHud: (hud: HudSnapshot) => void;
  onGameOver: (result: RunResult) => void;
}

interface Paddle {
  x: number;
  y: number;
  w: number;
  h: number;
  baseH: number;
  targetH: number;
  flash: number;
  vy: number;
}

interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  active: boolean;
  flame: number;
  trail: { x: number; y: number }[];
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  drag: number;
  gravity: number;
  streak: boolean;
}

interface Ring {
  x: number;
  y: number;
  radius: number;
  grow: number;
  life: number;
  max: number;
  color: string;
  width: number;
}

interface FloatText {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  size: number;
}

interface Orb {
  x: number;
  y: number;
  r: number;
  vy: number;
  type: PowerType;
  ttl: number;
  maxTtl: number;
  phase: number;
}

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const ACID = "#d4ff57";
const EMBER = "#ff6b4a";
const AQUA = "#65ead5";
const VIOLET = "#b9a1ff";

const POWER_META: Record<PowerType, { color: string; label: string }> = {
  wide: { color: ACID, label: "WIDE PADDLE" },
  slow: { color: AQUA, label: "SLO-MO" },
  shield: { color: VIOLET, label: "SHIELD ONLINE" },
  surge: { color: EMBER, label: "SURGE CHARGED" },
  stagger: { color: "#8be1ff", label: "STAGGER" },
};

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

export class NeonRallyEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private bgCanvas: HTMLCanvasElement | null = null;
  private cb: EngineCallbacks;
  private sfx: Sfx;
  private raf = 0;
  private last = 0;
  private resizeObserver: ResizeObserver | null = null;

  private w = 0;
  private h = 0;
  private dpr = 1;
  private status: GameStatus = "attract";
  private mode: GameMode = "solo";
  private difficulty: Difficulty = "casual";
  private clock = 0;
  private matchTime = 0;
  private hudClock = 0;
  private fpsClock = 0;
  private fpsFrames = 0;
  private fps = 60;
  private shake = 0;
  private level = 1;

  private paddleW = 11;
  private ballR = 10;
  private baseSpeed = 460;
  private maxSpeed = 860;

  private player: Paddle = {
    x: 0,
    y: 0,
    w: 11,
    h: 90,
    baseH: 90,
    targetH: 90,
    flash: 0,
    vy: 0,
  };
  private rival: Paddle = {
    x: 0,
    y: 0,
    w: 11,
    h: 90,
    baseH: 90,
    targetH: 90,
    flash: 0,
    vy: 0,
  };
  private ball: Ball = { x: 0, y: 0, vx: 0, vy: 0, r: 10, active: false, flame: 0, trail: [] };

  private playerScore = 0;
  private rivalScore = 0;
  private score = 0;
  private p2Score = 0;
  private combo = 0;
  private bestCombo = 0;
  private comboP2 = 0;
  private bestComboP2 = 0;
  private rally = 0;
  private bestRally = 0;
  private surge = 0;
  private surgeP2 = 0;
  private shield = 0;
  private shieldP2 = 0;
  private wideT = 0;
  private wideT2 = 0;
  private slowT = 0;
  private staggerT = 0;
  private staggerSide: "p1" | "p2" | null = null;
  private staggerUsed = false;
  private lastGoalAt = -999;
  private hits = 0;
  private lastSide: 1 | 2 = 1;
  private winner: "player" | "rival" | null = null;

  private serveTimer = 0;
  private pendingDir = -1;
  private orb: Orb | null = null;
  private orbTimer = 5.2;
  private aiError = 0;
  private barrierFlash = 0;
  private barrierFlashSide: "p1" | "p2" | null = null;

  private particles: Particle[] = [];
  private rings: Ring[] = [];
  private texts: FloatText[] = [];
  private keys = new Set<string>();
  private pointerStates: { p1: number | null; p2: number | null } = { p1: null, p2: null };
  private pointerTracks = new Map<number, { side: "p1" | "p2"; y: number }>();

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks, sfx: Sfx) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false }) as CanvasRenderingContext2D;
    this.cb = cb;
    this.sfx = sfx;

    this.resize();
    this.launchBall(-1);
    this.emitHud();

    this.canvas.style.touchAction = "none";
    this.canvas.addEventListener("pointermove", this.handlePointerMove);
    this.canvas.addEventListener("pointerdown", this.handlePointerDown);
    this.canvas.addEventListener("pointerup", this.handlePointerUp);
    this.canvas.addEventListener("pointercancel", this.handlePointerUp);
    this.canvas.addEventListener("pointerleave", this.handlePointerUp);
    this.canvas.addEventListener("pointerenter", this.handlePointerMove);
    window.addEventListener("keydown", this.handleKeyDown, { passive: false });
    window.addEventListener("keyup", this.handleKeyUp);
    window.addEventListener("blur", this.handleBlur);

    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(this.canvas);
    } else {
      window.addEventListener("resize", this.resize);
    }

    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  /* ------------------------------------------------------------------ */
  /* public API                                                          */
  /* ------------------------------------------------------------------ */

  start(mode: GameMode = this.mode, difficulty?: Difficulty) {
    if (difficulty) this.difficulty = difficulty;
    this.mode = mode;
    this.sfx.unlock();
    this.keys.clear();
    this.pointerTracks.clear();
    this.pointerStates = { p1: null, p2: null };
    this.resetMatch();
    this.status = "playing";
    this.sfx.start();
    this.sfx.startAmbience();
    this.serve(Math.random() < 0.5 ? 1 : -1, 0.55);
    this.emitHud();
  }

  pause() {
    if (this.status !== "playing") return;
    this.status = "paused";
    this.keys.clear();
    this.sfx.pause();
    this.sfx.stopAmbience();
    this.emitHud();
  }

  resume() {
    if (this.status !== "paused") return;
    this.status = "playing";
    this.last = performance.now();
    this.sfx.ui();
    this.sfx.startAmbience();
    this.emitHud();
  }

  togglePause() {
    if (this.status === "playing") this.pause();
    else if (this.status === "paused") this.resume();
  }

  quitToMenu() {
    this.keys.clear();
    this.pointerTracks.clear();
    this.pointerStates = { p1: null, p2: null };
    this.sfx.stopAmbience();
    this.status = "attract";
    this.resetMatch();
    this.status = "attract";
    this.launchBall(Math.random() > 0.5 ? 1 : -1);
    this.emitHud();
  }

  getStatus() {
    return this.status;
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener("pointermove", this.handlePointerMove);
    this.canvas.removeEventListener("pointerdown", this.handlePointerDown);
    this.canvas.removeEventListener("pointerup", this.handlePointerUp);
    this.canvas.removeEventListener("pointercancel", this.handlePointerUp);
    this.canvas.removeEventListener("pointerleave", this.handlePointerUp);
    this.canvas.removeEventListener("pointerenter", this.handlePointerMove);
    window.removeEventListener("keydown", this.handleKeyDown);
    window.removeEventListener("keyup", this.handleKeyUp);
    window.removeEventListener("blur", this.handleBlur);
    window.removeEventListener("resize", this.resize);
    this.resizeObserver?.disconnect();
  }

  /* ------------------------------------------------------------------ */
  /* setup / reset                                                       */
  /* ------------------------------------------------------------------ */

  private resize = () => {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(280, Math.round(rect.width));
    const h = Math.max(260, Math.round(rect.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    if (w === this.w && h === this.h && dpr === this.dpr && this.bgCanvas) return;

    const oldH = this.h;
    const oldW = this.w;
    this.w = w;
    this.h = h;
    this.dpr = dpr;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    this.paddleW = clamp(w * 0.014, 8, 13);
    this.ballR = clamp(Math.min(w, h) * 0.021, 7.5, 11);
    const baseH = clamp(h * 0.2, 54, 106);
    const padX = Math.max(14, w * 0.045);
    this.player.baseH = baseH;
    this.rival.baseH = baseH;
    this.player.w = this.paddleW;
    this.rival.w = this.paddleW;
    this.player.x = padX;
    this.rival.x = w - padX - this.paddleW;
    this.player.targetH = baseH * (this.wideT > 0 ? 1.62 : 1);
    this.rival.targetH = baseH * (this.wideT2 > 0 ? 1.62 : 1);

    const speedScale = DIFFICULTY_TABLE[this.difficulty].speedScale;
    this.baseSpeed = clamp(w * 0.58 * speedScale, 250, 480);
    this.maxSpeed = this.baseSpeed * 1.9;

    if (oldW === 0) {
      this.player.y = h / 2;
      this.rival.y = h / 2;
      this.player.h = baseH;
      this.rival.h = baseH;
      this.ball.x = w / 2;
      this.ball.y = h / 2;
      this.ball.r = this.ballR;
    } else {
      const sy = h / oldH;
      this.player.y = clamp(this.player.y * sy, baseH / 2, h - baseH / 2);
      this.rival.y = clamp(this.rival.y * sy, baseH / 2, h - baseH / 2);
      this.player.h = clamp(this.player.h * sy, baseH * 0.8, baseH * 1.8);
      this.rival.h = clamp(this.rival.h * sy, baseH * 0.8, baseH * 1.8);
      this.ball.x = clamp(this.ball.x * (w / oldW), 0, w);
      this.ball.y = clamp(this.ball.y * sy, 0, h);
      this.ball.r = this.ballR;
      this.ball.trail = [];
    }

    this.buildBackground();
  };

  private buildBackground() {
    const { w, h, dpr } = this;
    if (!w || !h) return;
    const bg = document.createElement("canvas");
    bg.width = Math.round(w * dpr);
    bg.height = Math.round(h * dpr);
    const c = bg.getContext("2d");
    if (!c) return;
    c.scale(dpr, dpr);

    const base = c.createLinearGradient(0, 0, w, h);
    base.addColorStop(0, "#081411");
    base.addColorStop(0.52, "#081014");
    base.addColorStop(1, "#100c13");
    c.fillStyle = base;
    c.fillRect(0, 0, w, h);

    const glowL = c.createRadialGradient(w * 0.06, h * 0.5, 0, w * 0.06, h * 0.5, w * 0.55);
    glowL.addColorStop(0, "rgba(212,255,87,0.10)");
    glowL.addColorStop(0.55, "rgba(212,255,87,0.028)");
    glowL.addColorStop(1, "rgba(212,255,87,0)");
    c.fillStyle = glowL;
    c.fillRect(0, 0, w, h);

    const glowR = c.createRadialGradient(w * 0.94, h * 0.56, 0, w * 0.94, h * 0.56, w * 0.52);
    glowR.addColorStop(0, "rgba(255,107,74,0.09)");
    glowR.addColorStop(0.6, "rgba(255,107,74,0.02)");
    glowR.addColorStop(1, "rgba(255,107,74,0)");
    c.fillStyle = glowR;
    c.fillRect(0, 0, w, h);

    // Fine dot matrix.
    c.fillStyle = "rgba(219,255,229,0.085)";
    const gap = w < 520 ? 26 : 32;
    for (let x = gap / 2; x < w; x += gap) {
      for (let y = gap / 2; y < h; y += gap) {
        const fade = 1 - Math.abs(x - w / 2) / (w * 0.75);
        c.globalAlpha = 0.28 + Math.max(0, fade) * 0.4;
        c.fillRect(x, y, 1.2, 1.2);
      }
    }
    c.globalAlpha = 1;

    // Center divider.
    c.save();
    c.strokeStyle = "rgba(226,255,235,0.16)";
    c.lineWidth = 1;
    c.setLineDash([4, 11]);
    c.beginPath();
    c.moveTo(w / 2, 20);
    c.lineTo(w / 2, h - 20);
    c.stroke();
    c.restore();

    // Center ring + crosshair.
    const midR = Math.min(w, h) * 0.13;
    c.strokeStyle = "rgba(212,255,87,0.14)";
    c.lineWidth = 1;
    c.beginPath();
    c.arc(w / 2, h / 2, midR, 0, Math.PI * 2);
    c.stroke();
    c.strokeStyle = "rgba(226,255,235,0.2)";
    c.beginPath();
    c.moveTo(w / 2 - 5, h / 2);
    c.lineTo(w / 2 + 5, h / 2);
    c.moveTo(w / 2, h / 2 - 5);
    c.lineTo(w / 2, h / 2 + 5);
    c.stroke();

    // Goal mouth accents.
    const goalGradient = c.createLinearGradient(0, 0, 18, 0);
    goalGradient.addColorStop(0, "rgba(212,255,87,0.22)");
    goalGradient.addColorStop(1, "rgba(212,255,87,0)");
    c.fillStyle = goalGradient;
    c.fillRect(0, 0, 18, h);
    const goalGradientR = c.createLinearGradient(w, 0, w - 18, 0);
    goalGradientR.addColorStop(0, "rgba(255,107,74,0.2)");
    goalGradientR.addColorStop(1, "rgba(255,107,74,0)");
    c.fillStyle = goalGradientR;
    c.fillRect(w - 18, 0, 18, h);

    // Corner brackets.
    c.strokeStyle = "rgba(226,255,235,0.22)";
    c.lineWidth = 1.2;
    const m = 15;
    const len = 18;
    const corners: [number, number, number, number][] = [
      [m, m, 1, 1],
      [w - m, m, -1, 1],
      [m, h - m, 1, -1],
      [w - m, h - m, -1, -1],
    ];
    for (const [x, y, sx, sy] of corners) {
      c.beginPath();
      c.moveTo(x, y + sy * len);
      c.lineTo(x, y);
      c.lineTo(x + sx * len, y);
      c.stroke();
    }

    // Letterbox vignette.
    const vig = c.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.72);
    vig.addColorStop(0, "rgba(0,0,0,0)");
    vig.addColorStop(1, "rgba(1,5,6,0.5)");
    c.fillStyle = vig;
    c.fillRect(0, 0, w, h);

    this.bgCanvas = bg;
  }

  private resetMatch() {
    this.playerScore = 0;
    this.rivalScore = 0;
    this.score = 0;
    this.p2Score = 0;
    this.combo = 0;
    this.bestCombo = 0;
    this.comboP2 = 0;
    this.bestComboP2 = 0;
    this.rally = 0;
    this.bestRally = 0;
    this.surge = 0;
    this.surgeP2 = 0;
    this.shield = 0;
    this.shieldP2 = 0;
    this.wideT = 0;
    this.wideT2 = 0;
    this.slowT = 0;
    this.staggerT = 0;
    this.staggerSide = null;
    this.staggerUsed = false;
    this.lastGoalAt = -999;
    this.hits = 0;
    this.lastSide = 1;
    this.matchTime = 0;
    this.winner = null;
    this.orb = null;
    this.orbTimer = 5.2;
    this.serveTimer = 0;
    this.barrierFlashSide = null;
    this.player.targetH = this.player.baseH;
    this.player.h = this.player.baseH;
    this.rival.h = this.rival.baseH;
    this.player.y = this.h / 2;
    this.rival.y = this.h / 2;
    this.player.flash = 0;
    this.rival.flash = 0;
    this.ball.flame = 0;
    this.ball.trail = [];
    this.particles = [];
    this.rings = [];
    this.texts = [];
    this.shake = 0;
    this.barrierFlash = 0;
    this.barrierFlashSide = null;
    this.aiError = 0;
    this.level = 1;
    this.rival.targetH = this.rival.baseH;
  }

  private launchBall(dir: 1 | -1) {
    const speed = this.baseSpeed;
    const angle = (Math.random() * 0.34 - 0.17) * dir;
    this.ball.x = this.w / 2;
    this.ball.y = this.h / 2 + (Math.random() * this.h * 0.12 - this.h * 0.06);
    this.ball.vx = Math.cos(angle) * speed * dir;
    this.ball.vy = Math.sin(angle) * speed * (Math.random() > 0.5 ? 1 : -1);
    if (Math.abs(this.ball.vy) < speed * 0.12) this.ball.vy = speed * 0.16 * (Math.random() > 0.5 ? 1 : -1);
    this.ball.r = this.ballR;
    this.ball.active = true;
    this.ball.flame = 0;
    this.ball.trail = [];
    this.shake = Math.max(this.shake, 3);
    this.sfx.serve();
  }

  private serve(dir: 1 | -1, delay: number) {
    this.ball.active = false;
    this.ball.x = this.w / 2;
    this.ball.y = this.h / 2;
    this.ball.trail = [];
    this.pendingDir = dir;
    this.serveTimer = delay;
    const table = DIFFICULTY_TABLE[this.difficulty];
    this.aiError = (Math.random() * 2 - 1) * this.player.baseH * table.errRefresh;
    if (this.status === "playing") {
      this.emitHud(true);
    }
  }

  /* ------------------------------------------------------------------ */
  /* main loop                                                           */
  /* ------------------------------------------------------------------ */

  private loop = (now: number) => {
    const raw = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    this.fpsFrames += 1;
    this.fpsClock += raw;
    if (this.fpsClock >= 0.6) {
      this.fps = clamp(Math.round(this.fpsFrames / this.fpsClock), 1, 144);
      this.fpsFrames = 0;
      this.fpsClock = 0;
    }

    if (this.status === "playing" || this.status === "attract") {
      this.update(raw);
    } else if (this.status === "gameover") {
      // Keep confetti and goal feedback alive behind the results overlay.
      this.shake = Math.max(0, this.shake - raw * 26);
      this.updateEffects(raw);
    }

    this.draw();
    this.hudClock += raw;
    if (this.hudClock >= 0.12) {
      this.hudClock = 0;
      if (this.status !== "paused") this.emitHud();
    }

    this.raf = requestAnimationFrame(this.loop);
  };

  private update(dt: number) {
    this.clock += dt;
    const live = this.status === "playing";

    if (live) {
      this.matchTime += dt;
      const table = DIFFICULTY_TABLE[this.difficulty];
      this.level = clamp(1 + Math.floor(this.matchTime / table.lvlTime) + Math.floor(this.playerScore / table.lvlScore), 1, 6);
      if (this.wideT > 0) {
        this.wideT = Math.max(0, this.wideT - dt);
        if (this.wideT === 0) this.player.targetH = this.player.baseH;
      }
      if (this.wideT2 > 0) {
        this.wideT2 = Math.max(0, this.wideT2 - dt);
        if (this.wideT2 === 0) this.rival.targetH = this.rival.baseH;
      }
      if (this.slowT > 0) this.slowT = Math.max(0, this.slowT - dt);
      if (this.staggerT > 0) {
        this.staggerT = Math.max(0, this.staggerT - dt);
        if (this.staggerT === 0) this.staggerSide = null;
      }
      this.player.targetH = this.player.baseH * (this.wideT > 0 ? 1.62 : 1);
      this.rival.targetH = this.rival.baseH * (this.wideT2 > 0 ? 1.62 : 1);
      this.barrierFlash = Math.max(0, this.barrierFlash - dt * 2.2);
      if (this.ball.flame > 0) this.ball.flame = Math.max(0, this.ball.flame - dt);
    }

    this.player.h = lerp(this.player.h, this.player.targetH, 1 - Math.exp(-dt * 10));
    this.rival.h = lerp(this.rival.h, this.rival.targetH, 1 - Math.exp(-dt * 10));
    this.player.flash = Math.max(0, this.player.flash - dt * 4.5);
    this.rival.flash = Math.max(0, this.rival.flash - dt * 4.5);
    this.shake = Math.max(0, this.shake - dt * 26);

    if (live) {
      this.updatePlayer(dt);
      this.updateRival(dt);
    } else {
      this.updateDemoPaddle(this.player, dt, 1.4);
      this.updateDemoPaddle(this.rival, dt, 1.25);
    }

    if (this.ball.active) {
      this.stepBall(dt);
      if (this.ball.active) {
        this.ball.trail.push({ x: this.ball.x, y: this.ball.y });
        if (this.ball.trail.length > (this.w < 560 ? 11 : 16)) this.ball.trail.shift();
      }
    } else if (live) {
      this.serveTimer -= dt;
      if (this.serveTimer <= 0) {
        this.launchBall(this.pendingDir === 1 ? 1 : -1);
      }
    }

    if (live) {
      this.updateOrb(dt);
    }

    this.updateEffects(dt);
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    const before = p.y;
    const up = this.keys.has("KeyW") || (this.mode === "solo" && this.keys.has("ArrowUp"));
    const down = this.keys.has("KeyS") || (this.mode === "solo" && this.keys.has("ArrowDown"));
    const factor = this.staggerSide === "p1" && this.staggerT > 0 ? 0.42 : 1;
    if (up || down) {
      const dir = (down ? 1 : 0) - (up ? 1 : 0);
      p.y += dir * this.h * 2.35 * factor * dt;
    } else if (this.pointerStates.p1 !== null) {
      p.y = this.pointerStates.p1;
    }
    p.y = clamp(p.y, p.h / 2 + 6, this.h - p.h / 2 - 6);
    p.vy = dt > 0 ? (p.y - before) / dt : 0;
  }

  private updateRivalLocal(dt: number) {
    const r = this.rival;
    const before = r.y;
    const up = this.keys.has("ArrowUp");
    const down = this.keys.has("ArrowDown");
    const factor = this.staggerSide === "p2" && this.staggerT > 0 ? 0.42 : 1;
    if (up || down) {
      const dir = (down ? 1 : 0) - (up ? 1 : 0);
      r.y += dir * this.h * 2.35 * factor * dt;
    } else if (this.pointerStates.p2 !== null) {
      r.y = this.pointerStates.p2;
    }
    r.y = clamp(r.y, r.h / 2 + 6, this.h - r.h / 2 - 6);
    r.vy = dt > 0 ? (r.y - before) / dt : 0;
  }

  private updateRival(dt: number) {
    if (this.mode === "local") {
      this.updateRivalLocal(dt);
      return;
    }
    const r = this.rival;
    const b = this.ball;
    let target = this.h / 2;
    if (b.active && b.vx > 0) {
      const t = Math.max(0, (r.x - b.x) / b.vx);
      let predicted = b.y + b.vy * t;
      const lo = b.r;
      const hi = this.h - b.r;
      const span = hi - lo;
      if (span > 0) {
        let k = (predicted - lo) % (span * 2);
        if (k < 0) k += span * 2;
        predicted = lo + (k <= span ? k : span * 2 - k);
      }
      target = predicted + this.aiError * (1 - Math.min(DIFFICULTY_TABLE[this.difficulty].retain, this.level * 0.05));
    } else if (b.active && b.vx <= 0) {
      target = this.h / 2 + Math.sin(this.clock * 0.9) * this.h * 0.08;
    }
    const table = DIFFICULTY_TABLE[this.difficulty];
    const speed = this.h * (table.aiSpeedBase + this.level * table.aiSpeedPerLvl) * (this.staggerSide === "p2" && this.staggerT > 0 ? 0.42 : 1);
    const before = r.y;
    const diff = target - r.y;
    const step = clamp(diff, -speed * dt, speed * dt);
    r.y = clamp(r.y + step, r.h / 2 + 6, this.h - r.h / 2 - 6);
    r.vy = dt > 0 ? (r.y - before) / dt : 0;
  }

  private updateDemoPaddle(p: Paddle, dt: number, speedMul: number) {
    if (!this.ball.active) return;
    const target = this.ball.y + Math.sin(this.clock * 1.5 + p.x) * 8;
    const speed = this.h * speedMul;
    const before = p.y;
    p.y = clamp(p.y + clamp(target - p.y, -speed * dt, speed * dt), p.h / 2 + 6, this.h - p.h / 2 - 6);
    p.vy = dt > 0 ? (p.y - before) / dt : 0;
  }

  private stepBall(dt: number) {
    const b = this.ball;
    const slow = this.slowT > 0 ? 0.64 : 1;
    const frameScale = slow * dt;
    const maxStep = Math.max(1, Math.ceil((Math.hypot(b.vx, b.vy) * frameScale) / (b.r * 1.6)));
    const steps = Math.min(6, maxStep);
    const sdt = frameScale / steps;

    for (let i = 0; i < steps; i += 1) {
      b.x += b.vx * sdt;
      b.y += b.vy * sdt;

      if (b.y - b.r <= 0 && b.vy < 0) {
        b.y = b.r;
        b.vy = Math.abs(b.vy);
        this.wallHit(b.x, b.y);
      } else if (b.y + b.r >= this.h && b.vy > 0) {
        b.y = this.h - b.r;
        b.vy = -Math.abs(b.vy);
        this.wallHit(b.x, b.y);
      }

      this.tryPaddleCollision(this.player, true);
      this.tryPaddleCollision(this.rival, false);

      if (b.x + b.r < 0) {
        this.resolveGoal("rival");
        return;
      }
      if (b.x - b.r > this.w) {
        this.resolveGoal("player");
        return;
      }
    }
  }

  private wallHit(x: number, y: number) {
    if (this.status !== "playing") return;
    this.burst(x, y, "rgba(226,255,235,0.9)", 4, 85, { size: 2, speed: 0.4 });
    this.sfx.wall();
    this.shake = Math.max(this.shake, 1.6);
  }

  private tryPaddleCollision(p: Paddle, isPlayer: boolean) {
    const b = this.ball;
    const movingTowards = isPlayer ? b.vx < 0 : b.vx > 0;
    if (!movingTowards) return;
    const withinX = isPlayer ? b.x - b.r <= p.x + p.w : b.x + b.r >= p.x;
    const overlappingX = isPlayer ? b.x + b.r >= p.x : b.x - b.r <= p.x + p.w;
    if (!withinX || !overlappingX) return;
    if (b.y + b.r < p.y - p.h / 2 || b.y - b.r > p.y + p.h / 2) return;

    const live = this.status === "playing";
    const sideColor = isPlayer ? ACID : EMBER;
    const rel = clamp((b.y - p.y) / (p.h / 2), -1, 1);
    const angle = rel * 0.94;
    let speed = Math.hypot(b.vx, b.vy) * 1.04 + 6;
    const currentCombo = isPlayer ? this.combo : this.comboP2;
    const currentSurge = isPlayer ? this.surge : this.surgeP2;
    this.lastSide = isPlayer ? 1 : 2;
    const armed = live && currentSurge >= 100;

    if (armed) {
      speed *= 1.5;
      if (isPlayer) this.surge = 0;
      else this.surgeP2 = 0;
      b.flame = 2.6;
      this.burst(isPlayer ? p.x + p.w : p.x, b.y, EMBER, 30, 300, { size: 4, speed: 2.4 });
      this.burst(isPlayer ? p.x + p.w : p.x, b.y, "#fff3c4", 16, 210, { size: 3, speed: 1.8 });
      this.rings.push({
        x: isPlayer ? p.x + p.w : p.x,
        y: b.y,
        radius: 8,
        grow: 300,
        life: 0.5,
        max: 0.5,
        color: EMBER,
        width: 3,
      });
      this.shake = Math.max(this.shake, 13);
      this.texts.push({
        x: isPlayer ? p.x + p.w + 26 : p.x - 26,
        y: b.y - 20,
        text: "SURGE!",
        life: 0.9,
        max: 0.9,
        color: EMBER,
        size: 18,
      });
      this.sfx.surge();
      this.haptic([12, 24, 30]);
    }

    speed = Math.min(speed, this.maxSpeed * (armed ? 1.45 : 1));
    const direction = isPlayer ? 1 : -1;
    b.vx = Math.cos(angle) * speed * direction;
    b.vy = Math.sin(angle) * speed + p.vy * 0.13;
    b.vy = clamp(b.vy, -this.maxSpeed, this.maxSpeed);
    if (isPlayer) {
      b.x = p.x + p.w + b.r;
    } else {
      b.x = p.x - b.r - 0.5;
      if (!armed) b.flame = 0;
    }
    p.flash = 1;

    if (live) {
      const combo = currentCombo + 1;
      if (isPlayer) {
        this.combo = combo;
        this.bestCombo = Math.max(this.bestCombo, combo);
      } else {
        this.comboP2 = combo;
        this.bestComboP2 = Math.max(this.bestComboP2, combo);
      }
      this.rally += 1;
      this.bestRally = Math.max(this.bestRally, this.rally);
      this.hits += 1;
      const gained = 20 * Math.min(combo, 9);
      if (isPlayer) this.score += gained;
      else this.p2Score += gained;

      // Charge the surge bar (skipped for the armed shot itself).
      if ((isPlayer ? this.surge : this.surgeP2) < 100) {
        const old = isPlayer ? this.surge : this.surgeP2;
        const next = Math.min(100, old + (armed ? 0 : 18));
        if (isPlayer) this.surge = next;
        else this.surgeP2 = next;
        if (old < 100 && next >= 100) this.sfx.surgeReady();
      }

      if (combo === 3 || combo === 5 || combo === 7 || combo === 9) {
        this.sfx.comboMilestone(combo);
      }
      if (combo === 5 || combo === 10) {
        this.texts.push({
          x: b.x,
          y: b.y - b.r - 16,
          text: `STREAK ×${combo}!`,
          life: 0.8,
          max: 0.8,
          color: "#fff3c4",
          size: 15,
        });
      }

      this.texts.push({
        x: isPlayer ? p.x + p.w + 22 : p.x - 22,
        y: b.y - 14,
        text: `+${gained}`,
        life: 0.62,
        max: 0.62,
        color: combo >= 5 ? EMBER : sideColor,
        size: 13,
      });
      this.shake = Math.max(this.shake, 4 + Math.min(combo, 9) * 0.45);
      this.sfx.hit(combo, isPlayer);
      this.emitHud(true);
    }

    if (isPlayer) {
      this.burst(p.x + p.w, b.y, ACID, 14, 200, { size: 3, speed: 0.9 });
      this.burst(p.x + p.w, b.y, "#f4ffdf", 7, 140, { size: 2, speed: 0.6 });
    } else {
      this.burst(p.x, b.y, EMBER, 10, 150, { size: 2.5, speed: 0.7 });
      this.shake = Math.max(this.shake, 2.4);
      if (live) this.aiError = (Math.random() * 2 - 1) * this.player.baseH * DIFFICULTY_TABLE[this.difficulty].errRefresh;
    }

    if (live) {
      this.rings.push({
        x: isPlayer ? p.x + p.w : p.x,
        y: b.y,
        radius: 4,
        grow: 150,
        life: 0.32,
        max: 0.32,
        color: isPlayer ? ACID : EMBER,
        width: 1.6,
      });
    }
  }

  private resolveGoal(side: "player" | "rival") {
    if (this.status === "attract") {
      this.burst(clamp(this.ball.x, 6, this.w - 6), clamp(this.ball.y, 6, this.h - 6), side === "player" ? EMBER : ACID, 12, 190, {
        size: 3,
        speed: 0.8,
      });
      this.launchBall(side === "player" ? -1 : 1);
      return;
    }
    if (this.status !== "playing") return;

    this.bestRally = Math.max(this.bestRally, this.rally);
    this.ball.active = false;

    const concedeSide = side === "player" ? "rival" : "player";
    const hasShield = concedeSide === "player" ? this.shield > 0 : this.shieldP2 > 0;
    const prevComboMax = Math.max(this.combo, this.comboP2);

    if (hasShield) {
      if (concedeSide === "player") {
        this.shield = 0;
        this.barrierFlashSide = "p1";
      } else {
        this.shieldP2 = 0;
        this.barrierFlashSide = "p2";
      }
      this.barrierFlash = 1;
      this.ball.active = true;
      if (concedeSide === "player") {
        this.ball.x = Math.max(this.ball.r + 10, this.w * 0.18);
        this.ball.vx = Math.abs(this.ball.vx) * 1.05;
      } else {
        this.ball.x = Math.min(this.w - this.ball.r - 10, this.w * 0.82);
        this.ball.vx = -Math.abs(this.ball.vx) * 1.05;
      }
      this.ball.vy = this.ball.vy * 1.05 + (Math.random() * 120 - 60);
      this.burst(this.ball.x, this.ball.y, VIOLET, 30, 280, { size: 3.5, speed: 1.6 });
      this.rings.push({
        x: concedeSide === "player" ? 4 : this.w - 4,
        y: this.ball.y,
        radius: 10,
        grow: 260,
        life: 0.55,
        max: 0.55,
        color: VIOLET,
        width: 3,
      });
      this.texts.push({
        x: concedeSide === "player" ? this.w * 0.24 : this.w * 0.76,
        y: this.h * 0.5,
        text: "SAVED!",
        life: 1,
        max: 1,
        color: VIOLET,
        size: 20,
      });
      this.shake = Math.max(this.shake, 12);
      this.sfx.shield();
      this.emitHud(true);
      return;
    }

    const quickGoal = this.rally >= 3 && this.matchTime - this.lastGoalAt < 8;
    const rallyBonus = this.rally >= 10 ? 300 : 0;
    const bonus = (this.ball.flame > 0 ? 500 : 250) + rallyBonus + (quickGoal ? 250 : 0);
    this.lastGoalAt = this.matchTime;

    if (side === "player") {
      this.playerScore += 1;
      this.score += 500 + this.rally * 15 + bonus;
      this.burst(this.w - 8, this.ball.y, ACID, 34, 320, { size: 4, speed: 2 });
      this.burst(this.w - 8, this.ball.y, "#ffffff", 14, 210, { size: 2.5, speed: 1.2 });
      this.rings.push({ x: this.w, y: this.ball.y, radius: 8, grow: 420, life: 0.6, max: 0.6, color: ACID, width: 3 });
      this.texts.push({
        x: this.w * 0.56,
        y: this.h * 0.42,
        text:
          this.mode === "local"
            ? quickGoal
              ? "P1 SPEED GOAL"
              : rallyBonus > 0
                ? "P1 PERFECT RALLY"
                : this.ball.flame > 0
                  ? "P1 POWER GOAL"
                  : "P1 SCORES"
            : bonus > 250
              ? quickGoal
                ? "SPEED GOAL +750"
                : rallyBonus > 0
                  ? "PERFECT RALLY +800"
                  : "POWER GOAL +750"
              : quickGoal
                ? "SPEED GOAL +750"
                : rallyBonus > 0
                  ? "PERFECT RALLY +800"
                  : "POINT +500",
        life: 1.1,
        max: 1.1,
        color: ACID,
        size: 18,
      });
      this.shake = Math.max(this.shake, 15);
      this.sfx.playerScore();
      this.haptic([18, 30, 22]);
      // Concede penalty for the player who conceded (P2 in 2P, no AI in solo).
      if (this.mode === "local") this.surgeP2 = Math.max(0, this.surgeP2 - 25);
    } else {
      this.rivalScore += 1;
      this.p2Score += 500 + this.rally * 15 + bonus;
      this.surge = Math.max(0, this.surge - 25);
      this.burst(8, this.ball.y, EMBER, 28, 290, { size: 4, speed: 1.8 });
      this.rings.push({ x: 0, y: this.ball.y, radius: 8, grow: 380, life: 0.55, max: 0.55, color: EMBER, width: 3 });
      this.texts.push({
        x: this.w * 0.17,
        y: this.h * 0.42,
        text: this.mode === "local" ? "P2 SCORES" : quickGoal ? "RIVAL SPEED GOAL" : "RIVAL POINT",
        life: 1,
        max: 1,
        color: EMBER,
        size: 17,
      });
      this.shake = Math.max(this.shake, 13);
      this.sfx.rivalScore();
      this.haptic(16);
    }

    this.ball.flame = 0;
    this.combo = 0;
    this.comboP2 = 0;
    if (prevComboMax >= 3) this.sfx.comboBreak();
    this.rally = 0;
    this.aiError = (Math.random() * 2 - 1) * this.player.baseH * 0.45;
    this.emitHud(true);

    if (this.playerScore >= 7 || this.rivalScore >= 7) {
      this.endMatch(this.playerScore >= 7);
      return;
    }
    this.serve(side === "player" ? 1 : -1, 0.85);
  }

  private endMatch(won: boolean) {
    this.status = "gameover";
    this.winner = won ? "player" : "rival";
    this.ball.active = false;
    this.sfx.stopAmbience();
    if (won) {
      for (let i = 0; i < 3; i += 1) {
        this.burst(this.w * (0.3 + Math.random() * 0.4), this.h * 0.45, i % 2 ? ACID : "#fff3c4", 24, 280, {
          size: 4,
          speed: 1.8,
        });
      }
      this.shake = 18;
    }
    this.sfx.gameOver(won);
    this.emitHud(true);
    this.cb.onGameOver({
      mode: this.mode,
      score: Math.round(this.score),
      p2Score: Math.round(this.p2Score),
      playerScore: this.playerScore,
      rivalScore: this.rivalScore,
      bestRally: this.bestRally,
      bestCombo: this.bestCombo,
      bestComboP2: this.bestComboP2,
      duration: this.matchTime,
      hits: this.hits,
      won,
    });
  }

  /* ------------------------------------------------------------------ */
  /* power-ups                                                          */
  /* ------------------------------------------------------------------ */

  private updateOrb(dt: number) {
    if (!this.orb) {
      this.orbTimer -= dt;
      if (this.orbTimer <= 0) this.spawnOrb();
      return;
    }
    const orb = this.orb;
    orb.ttl -= dt;
    orb.phase += dt * 2;
    orb.y += orb.vy * dt;
    if (orb.y < orb.r + 20) {
      orb.y = orb.r + 20;
      orb.vy = Math.abs(orb.vy);
    } else if (orb.y > this.h - orb.r - 20) {
      orb.y = this.h - orb.r - 20;
      orb.vy = -Math.abs(orb.vy);
    }
    if (orb.ttl <= 0) {
      this.orb = null;
      this.orbTimer = 4.5 + Math.random() * 2;
      return;
    }
    const hit = (p: Paddle) => {
      const hitX = orb.x + orb.r >= p.x && orb.x - orb.r <= p.x + p.w;
      const hitY = Math.abs(orb.y - p.y) <= p.h / 2 + orb.r;
      return hitX && hitY;
    };
    if (hit(this.player)) {
      this.collectOrb(orb, "p1");
      return;
    }
    if (this.mode === "local" && hit(this.rival)) {
      this.collectOrb(orb, "p2");
    }
  }

  private spawnOrb() {
    const types: PowerType[] = this.staggerUsed ? ["wide", "slow", "shield", "surge"] : ["wide", "slow", "shield", "surge", "stagger"];
    let type = types[Math.floor(Math.random() * types.length)];
    if (this.rivalScore >= 5 && Math.random() < 0.45) type = "shield";
    if (this.playerScore >= 5 && Math.random() < 0.3) type = "surge";
    if (type === "stagger" && this.staggerUsed) type = "wide";
    if (type === "stagger") this.staggerUsed = true;
    const side: "p1" | "p2" = this.mode === "local" && Math.random() < 0.5 ? "p2" : "p1";
    const xFactor = side === "p1" ? 0.15 + Math.random() * 0.23 : 0.6 + Math.random() * 0.22;
    this.orb = {
      x: this.w * xFactor,
      y: this.h * (0.26 + Math.random() * 0.48),
      r: clamp(Math.min(this.w, this.h) * 0.042, 14, 21),
      vy: (Math.random() > 0.5 ? 1 : -1) * (22 + Math.random() * 26),
      type,
      ttl: 9,
      maxTtl: 9,
      phase: Math.random() * 6,
    };
    this.orbTimer = 6 + Math.random() * 3;
    this.sfx.orbSpawn();
  }

  private collectOrb(orb: Orb, side: "p1" | "p2" = "p1") {
    const meta = POWER_META[orb.type];
    if (orb.type === "wide") {
      if (side === "p1") {
        this.wideT = 8;
        this.player.targetH = this.player.baseH * 1.62;
      } else {
        this.wideT2 = 8;
        this.rival.targetH = this.rival.baseH * 1.62;
      }
    } else if (orb.type === "slow") {
      this.slowT = 5;
    } else if (orb.type === "shield") {
      if (side === "p1") this.shield = 1;
      else this.shieldP2 = 1;
    } else if (orb.type === "stagger") {
      const rivalSide = side === "p1" ? "p2" : "p1";
      this.staggerSide = rivalSide;
      this.staggerT = 4.5;
      this.texts.push({
        x: clamp(orb.x, this.w * 0.18, this.w * 0.82),
        y: orb.y - 40,
        text: side === "p1" ? "RIVAL STAGGERED" : "P1 STAGGERED",
        life: 1.15,
        max: 1.15,
        color: "#8be1ff",
        size: 12,
      });
    } else {
      const old = side === "p1" ? this.surge : this.surgeP2;
      const next = Math.min(100, old + 60);
      if (side === "p1") this.surge = next;
      else this.surgeP2 = next;
      if (old < 100 && next >= 100) this.sfx.surgeReady();
    }
    this.orb = null;
    this.orbTimer = 5.5 + Math.random() * 3;
    this.burst(orb.x, orb.y, meta.color, 26, 260, { size: 3.5, speed: 1.6 });
    this.rings.push({ x: orb.x, y: orb.y, radius: orb.r, grow: 240, life: 0.55, max: 0.55, color: meta.color, width: 2.5 });
    this.texts.push({
      x: clamp(orb.x, this.w * 0.18, this.w * 0.82),
      y: orb.y - 26,
      text: meta.label,
      life: 1.15,
      max: 1.15,
      color: meta.color,
      size: 14,
    });
    this.sfx.power();
    this.haptic(10);
    this.shake = Math.max(this.shake, 5);
    this.emitHud(true);
  }

  /* ------------------------------------------------------------------ */
  /* effects                                                            */
  /* ------------------------------------------------------------------ */

  private haptic(pattern: number | number[]) {
    try {
      if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
        navigator.vibrate(pattern);
      }
    } catch {
      /* vibration is optional */
    }
  }

  private burst(
    x: number,
    y: number,
    color: string,
    count: number,
    speed: number,
    opts: { size?: number; speed?: number; gravity?: number; spread?: number } = {},
  ) {
    const size = opts.size ?? 3;
    const gravity = opts.gravity ?? 140;
    const spread = opts.spread ?? Math.PI * 2;
    const baseAngle = -Math.PI / 2;
    for (let i = 0; i < count; i += 1) {
      if (this.particles.length > (this.w < 560 ? 160 : 280)) this.particles.shift();
      const angle = baseAngle + (Math.random() - 0.5) * spread + (spread === Math.PI * 2 ? Math.PI : 0);
      const velocity = speed * (0.35 + Math.random() * 0.85) * (opts.speed ?? 1);
      const life = 0.3 + Math.random() * 0.55;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity,
        life,
        max: life,
        size: size * (0.55 + Math.random() * 0.9),
        color,
        drag: 0.9 + Math.random() * 0.07,
        gravity,
        streak: Math.random() > 0.55,
      });
    }
  }

  private updateEffects(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i -= 1) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += p.gravity * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
    }
    for (let i = this.rings.length - 1; i >= 0; i -= 1) {
      const r = this.rings[i];
      r.life -= dt;
      r.radius += r.grow * dt;
      if (r.life <= 0) this.rings.splice(i, 1);
    }
    for (let i = this.texts.length - 1; i >= 0; i -= 1) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= dt * 34;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  }

  /* ------------------------------------------------------------------ */
  /* hud                                                                */
  /* ------------------------------------------------------------------ */

  private emitHud(force = false) {
    void force;
    this.cb.onHud({
      status: this.status,
      mode: this.mode,
      playerScore: this.playerScore,
      rivalScore: this.rivalScore,
      score: Math.round(this.score),
      p2Score: Math.round(this.p2Score),
      combo: this.combo,
      comboP2: this.comboP2,
      lastSide: this.lastSide,
      bestCombo: this.bestCombo,
      bestComboP2: this.bestComboP2,
      rally: this.rally,
      bestRally: this.bestRally,
      surge: Math.round(this.surge),
      surgeP2: Math.round(this.surgeP2),
      shield: this.shield > 0,
      shieldP2: this.shieldP2 > 0,
      wide: this.wideT,
      wideP2: this.wideT2,
      slow: this.slowT,
      time: this.matchTime,
      fps: this.fps,
      level: this.level,
      winner: this.winner,
      staggerSide: this.staggerSide,
      stagger: this.staggerT,
    });
  }

  /* ------------------------------------------------------------------ */
  /* input                                                              */
  /* ------------------------------------------------------------------ */

  private pointerSideFor(x: number): "p1" | "p2" {
    if (this.mode !== "local") return "p1";
    return x < this.w * 0.5 ? "p1" : "p2";
  }

  private recomputePointers() {
    this.pointerStates.p1 = null;
    this.pointerStates.p2 = null;
    for (const v of this.pointerTracks.values()) {
      this.pointerStates[v.side] = v.y;
    }
  }

  private handlePointerMove = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = clamp(e.clientY - rect.top, 0, rect.height);
    const side = this.pointerSideFor(x);
    this.pointerTracks.set(e.pointerId, { side, y });
    this.recomputePointers();
  };

  private handlePointerDown = (e: PointerEvent) => {
    this.handlePointerMove(e);
    try {
      this.canvas.setPointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  };

  private handlePointerUp = (e: PointerEvent) => {
    if (this.pointerTracks.delete(e.pointerId)) {
      this.recomputePointers();
    }
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
    if (e.code === "ArrowUp" || e.code === "ArrowDown" || e.code === "KeyW" || e.code === "KeyS") {
      this.keys.add(e.code);
      if (this.status === "playing") e.preventDefault();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private handleBlur = () => {
    this.keys.clear();
    this.pointerTracks.clear();
    this.pointerStates = { p1: null, p2: null };
  };

  /* ------------------------------------------------------------------ */
  /* rendering                                                          */
  /* ------------------------------------------------------------------ */

  private draw() {
    const ctx = this.ctx;
    const { w, h } = this;
    if (!w || !h) return;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (this.bgCanvas) {
      ctx.drawImage(this.bgCanvas, 0, 0, w, h);
    } else {
      ctx.fillStyle = "#081210";
      ctx.fillRect(0, 0, w, h);
    }

    const shakeX = this.shake > 0 ? (Math.random() * 2 - 1) * this.shake : 0;
    const shakeY = this.shake > 0 ? (Math.random() * 2 - 1) * this.shake : 0;
    ctx.save();
    ctx.translate(shakeX, shakeY);

    if (this.orb) this.drawOrb(this.orb);

    // Trails first.
    this.drawTrail();

    if (this.shield > 0 || this.shieldP2 > 0 || this.barrierFlash > 0) this.drawShield();

    this.drawPaddle(this.player, ACID, true);
    this.drawPaddle(this.rival, EMBER, false);

    if (this.staggerT > 0 && this.staggerSide) this.drawStaggerAura(this.staggerSide);

    if (this.ball.active) this.drawBall();
    else this.drawServe();

    this.drawParticles();
    this.drawRings();
    this.drawTexts();

    if (this.slowT > 0) {
      const v = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.18, w / 2, h / 2, Math.max(w, h) * 0.7);
      v.addColorStop(0, "rgba(101,234,213,0)");
      v.addColorStop(1, "rgba(101,234,213,0.13)");
      ctx.fillStyle = v;
      ctx.fillRect(0, 0, w, h);
    }

    ctx.restore();
  }

  private drawTrail() {
    const ctx = this.ctx;
    const b = this.ball;
    if (!b.active) return;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const color = b.flame > 0 ? "#ff8a3d" : this.lastSide === 2 ? EMBER : ACID;
    for (let i = 0; i < b.trail.length; i += 1) {
      const t = b.trail[i];
      const p = i / b.trail.length;
      ctx.globalAlpha = p * 0.3;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(t.x, t.y, b.r * (0.28 + p * 0.85), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawPaddle(p: Paddle, color: string, isPlayer: boolean) {
    const ctx = this.ctx;
    const x = p.x;
    const y = p.y - p.h / 2;
    ctx.save();
    const flash = p.flash;
    const grad = ctx.createLinearGradient(x, y, x + p.w, y + p.h);
    grad.addColorStop(0, color);
    grad.addColorStop(0.55, isPlayer ? "#ecffab" : "#ffb09b");
    grad.addColorStop(1, color);
    ctx.shadowColor = color;
    ctx.shadowBlur = 16 + flash * 22;
    ctx.fillStyle = grad;
    roundedRect(ctx, x, y, p.w, p.h, p.w / 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.globalAlpha = 0.7 + flash * 0.3;
    ctx.fillStyle = "rgba(255,255,255,0.55)";
    roundedRect(ctx, x + p.w * 0.28, y + p.h * 0.08, Math.max(1.5, p.w * 0.18), p.h * 0.84, p.w * 0.2);
    ctx.fill();
    if (flash > 0.05) {
      ctx.globalAlpha = flash * 0.7;
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.4;
      roundedRect(ctx, x - 3, y - 3, p.w + 6, p.h + 6, (p.w + 6) / 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawBall() {
    const ctx = this.ctx;
    const b = this.ball;
    const flame = b.flame > 0;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const aura = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r * 4.4);
    aura.addColorStop(0, flame ? "rgba(255,147,61,0.7)" : "rgba(212,255,87,0.5)");
    aura.addColorStop(0.45, flame ? "rgba(255,106,74,0.18)" : "rgba(212,255,87,0.12)");
    aura.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r * 4.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.shadowColor = flame ? EMBER : "#eaffb0";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#fbfff4";
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = flame ? EMBER : ACID;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r * 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(b.x - b.r * 0.18, b.y - b.r * 0.2, b.r * 0.24, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private drawServe() {
    const ctx = this.ctx;
    const x = this.w / 2;
    const y = this.h / 2;
    const pulse = 0.6 + Math.sin(this.clock * 6) * 0.25;
    ctx.save();
    ctx.globalAlpha = 0.75;
    ctx.strokeStyle = "rgba(212,255,87,0.6)";
    ctx.lineWidth = 1.4;
    ctx.setLineDash([4, 6]);
    ctx.beginPath();
    ctx.arc(x, y, 26 + pulse * 8, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#fbfff4";
    ctx.beginPath();
    ctx.arc(x, y, this.ball.r * 0.85, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(226,255,235,0.55)";
    ctx.font = "500 9px 'IBM Plex Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText("READY", x, y + 46);
    ctx.restore();
  }

  private drawStaggerAura(side: "p1" | "p2") {
    const ctx = this.ctx;
    const p = side === "p1" ? this.player : this.rival;
    const alpha = 0.25 + Math.sin(this.clock * 6) * 0.1;
    const r = p.h * 0.72;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const grad = ctx.createRadialGradient(p.x + p.w / 2, p.y, 0, p.x + p.w / 2, p.y, r);
    grad.addColorStop(0, `rgba(139,225,255,${alpha * 0.5})`);
    grad.addColorStop(0.55, `rgba(139,225,255,${alpha * 0.18})`);
    grad.addColorStop(1, "rgba(139,225,255,0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(p.x + p.w / 2, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    // Ice shards
    ctx.strokeStyle = `rgba(214,245,255,${alpha + 0.35})`;
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 5; i += 1) {
      const a = (Math.PI * 2 * i) / 5 + this.clock * 0.9;
      const x1 = p.x + p.w / 2 + Math.cos(a) * (p.h / 2 + 6);
      const y1 = p.y + Math.sin(a) * (p.h / 2 + 6);
      const x2 = p.x + p.w / 2 + Math.cos(a) * (p.h / 2 + 13);
      const y2 = p.y + Math.sin(a) * (p.h / 2 + 13);
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawShieldSide(ctx: CanvasRenderingContext2D, side: "p1" | "p2") {
    const w = this.w;
    const h = this.h;
    const active = side === "p1" ? this.shield > 0 : this.shieldP2 > 0;
    const flashOn = this.barrierFlashSide === side && this.barrierFlash > 0;
    const alpha = active ? 0.3 + Math.sin(this.clock * 3) * 0.08 : this.barrierFlash * 0.7;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const pad = side === "p1" ? this.player.x : this.rival.x;
    const grad = side === "p1"
      ? ctx.createLinearGradient(0, 0, w * 0.22, 0)
      : ctx.createLinearGradient(w, 0, w - w * 0.22, 0);
    grad.addColorStop(0, `rgba(185,161,255,${alpha})`);
    grad.addColorStop(0.4, `rgba(185,161,255,${alpha * 0.22})`);
    grad.addColorStop(1, "rgba(185,161,255,0)");
    ctx.fillStyle = grad;
    if (side === "p1") ctx.fillRect(0, 0, w * 0.22, h);
    else ctx.fillRect(w - w * 0.22, 0, w * 0.22, h);
    ctx.strokeStyle = `rgba(214,202,255,${active ? 0.8 : flashOn ? this.barrierFlash : 0.35})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(side === "p1" ? pad - 6 : pad + this.rival.w + 6, h * 0.1);
    ctx.lineTo(side === "p1" ? pad - 6 : pad + this.rival.w + 6, h * 0.9);
    ctx.stroke();
    ctx.restore();
  }

  private drawShield() {
    const ctx = this.ctx;
    if (this.shield > 0 || (this.barrierFlashSide === "p1" && this.barrierFlash > 0)) this.drawShieldSide(ctx, "p1");
    if (this.shieldP2 > 0 || (this.barrierFlashSide === "p2" && this.barrierFlash > 0)) this.drawShieldSide(ctx, "p2");
  }

  private drawOrb(orb: Orb) {
    const ctx = this.ctx;
    const meta = POWER_META[orb.type];
    const pulse = 1 + Math.sin(orb.phase * 2.4) * 0.08;
    const fade = clamp(orb.ttl / 1.2, 0, 1);
    ctx.save();
    ctx.globalAlpha = fade;
    ctx.translate(orb.x, orb.y);
    ctx.globalCompositeOperation = "lighter";
    const aura = ctx.createRadialGradient(0, 0, 0, 0, 0, orb.r * 3);
    aura.addColorStop(0, `${meta.color}66`);
    aura.addColorStop(1, `${meta.color}00`);
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(0, 0, orb.r * 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";

    ctx.rotate(Math.sin(orb.phase) * 0.12);
    ctx.fillStyle = "rgba(8,16,16,0.9)";
    ctx.strokeStyle = meta.color;
    ctx.lineWidth = 1.6;
    ctx.shadowColor = meta.color;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(0, 0, orb.r * pulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;

    ctx.strokeStyle = meta.color;
    ctx.lineWidth = 1;
    ctx.globalAlpha = fade * 0.65;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.arc(0, 0, orb.r * 1.55, orb.phase, orb.phase + Math.PI * 1.5);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = fade;

    ctx.fillStyle = meta.color;
    ctx.strokeStyle = meta.color;
    ctx.lineWidth = 1.8;
    const s = orb.r * 0.48;
    if (orb.type === "wide") {
      ctx.fillRect(-s, -s * 0.7, s * 2, s * 0.48);
      ctx.fillRect(-s, s * 0.22, s * 2, s * 0.48);
    } else if (orb.type === "slow") {
      ctx.beginPath();
      ctx.arc(0, 0, s, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -s * 0.6);
      ctx.moveTo(0, 0);
      ctx.lineTo(s * 0.5, s * 0.2);
      ctx.stroke();
    } else if (orb.type === "shield") {
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.lineTo(s * 0.85, -s * 0.55);
      ctx.lineTo(s * 0.7, s * 0.45);
      ctx.lineTo(0, s);
      ctx.lineTo(-s * 0.7, s * 0.45);
      ctx.lineTo(-s * 0.85, -s * 0.55);
      ctx.closePath();
      ctx.stroke();
    } else if (orb.type === "stagger") {
      ctx.lineWidth = 1.6;
      for (let i = 0; i < 3; i += 1) {
        const a = (Math.PI / 3) * i;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * -s, Math.sin(a) * -s);
        ctx.lineTo(Math.cos(a) * s, Math.sin(a) * s);
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(s * 0.2, -s);
      ctx.lineTo(-s * 0.55, s * 0.12);
      ctx.lineTo(0, s * 0.12);
      ctx.lineTo(-s * 0.15, s);
      ctx.lineTo(s * 0.65, -s * 0.12);
      ctx.lineTo(s * 0.1, -s * 0.12);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.globalAlpha = fade * 0.6;
    ctx.fillStyle = meta.color;
    ctx.font = "500 8px 'IBM Plex Mono', monospace";
    ctx.textAlign = "center";
    ctx.fillText(meta.label, orb.x, orb.y + orb.r * 2.2);
    ctx.restore();
  }

  private drawParticles() {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const p of this.particles) {
      const a = clamp(p.life / p.max, 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = p.color;
      if (p.streak) {
        ctx.lineWidth = Math.max(1, p.size * 0.55);
        ctx.strokeStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.vx * 0.022, p.y - p.vy * 0.022);
        ctx.stroke();
      } else {
        const size = p.size * (0.4 + a * 0.75);
        ctx.fillRect(p.x - size / 2, p.y - size / 2, size, size);
      }
    }
    ctx.restore();
  }

  private drawRings() {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const ring of this.rings) {
      const a = clamp(ring.life / ring.max, 0, 1);
      ctx.globalAlpha = a * 0.7;
      ctx.strokeStyle = ring.color;
      ctx.lineWidth = ring.width * a + 0.4;
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.radius, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawTexts() {
    const ctx = this.ctx;
    ctx.save();
    ctx.textAlign = "center";
    for (const t of this.texts) {
      const a = clamp(t.life / t.max, 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = t.color;
      ctx.font = `600 ${t.size}px 'Space Grotesk', sans-serif`;
      ctx.shadowColor = "rgba(0,0,0,0.5)";
      ctx.shadowBlur = 6;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.restore();
  }
}
