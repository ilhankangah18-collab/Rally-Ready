export type ScoreEntry = {
  id: string;
  tag: string;
  score: number;
  rally: number;
  bestCombo: number;
  goals: string;
  won: boolean;
  date: number;
};

const SCORES_KEY = "neon-rally:scores:v1";
const TAG_KEY = "neon-rally:tag:v1";
const MUTE_KEY = "neon-rally:muted:v1";

const seedScores = (): ScoreEntry[] => {
  const now = Date.now();
  return [
    { id: "seed-nova", tag: "NOVA", score: 4280, rally: 15, bestCombo: 7, goals: "7–4", won: true, date: now - 864e5 * 2 },
    { id: "seed-kira", tag: "KIRA", score: 3160, rally: 12, bestCombo: 6, goals: "7–5", won: true, date: now - 864e5 * 3 },
    { id: "seed-zen", tag: "ZEN", score: 2340, rally: 10, bestCombo: 5, goals: "6–7", won: false, date: now - 864e5 * 5 },
    { id: "seed-vex", tag: "VEX", score: 1670, rally: 8, bestCombo: 4, goals: "5–7", won: false, date: now - 864e5 * 7 },
    { id: "seed-milo", tag: "MILO", score: 980, rally: 5, bestCombo: 3, goals: "3–7", won: false, date: now - 864e5 * 9 },
    { id: "seed-echo", tag: "ECHO", score: 460, rally: 3, bestCombo: 2, goals: "1–7", won: false, date: now - 864e5 * 12 },
  ];
};

const sanitizeScores = (input: unknown): ScoreEntry[] | null => {
  if (!Array.isArray(input)) return null;
  const rows = input.filter((row): row is ScoreEntry => {
    if (!row || typeof row !== "object") return false;
    const r = row as Partial<ScoreEntry>;
    return typeof r.id === "string" && typeof r.tag === "string" && typeof r.score === "number";
  });
  if (!rows.length) return null;
  return rows
    .map((row) => ({
      ...row,
      rally: Number.isFinite(row.rally) ? row.rally : 0,
      bestCombo: Number.isFinite(row.bestCombo) ? row.bestCombo : 0,
      goals: typeof row.goals === "string" ? row.goals : "0–0",
      won: Boolean(row.won),
      date: Number.isFinite(row.date) ? row.date : Date.now(),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);
};

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (!raw) return seedScores();
    return sanitizeScores(JSON.parse(raw)) ?? seedScores();
  } catch {
    return seedScores();
  }
}

export function saveScores(scores: ScoreEntry[]) {
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(scores.slice(0, 8)));
  } catch {
    /* storage can be disabled */
  }
}

export function loadTag(): string {
  try {
    const raw = localStorage.getItem(TAG_KEY);
    if (raw && /^[A-Z0-9]{2,5}$/.test(raw)) return raw;
  } catch {
    /* noop */
  }
  return "ACE";
}

export function saveTag(tag: string) {
  try {
    localStorage.setItem(TAG_KEY, tag);
  } catch {
    /* noop */
  }
}

export function loadMuted(): boolean {
  try {
    return localStorage.getItem(MUTE_KEY) === "1";
  } catch {
    return false;
  }
}

export function saveMuted(muted: boolean) {
  try {
    localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
  } catch {
    /* noop */
  }
}

export function makeId() {
  return `run-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function formatScore(n: number) {
  return Math.max(0, Math.round(n)).toLocaleString("en-US");
}

export function formatDuration(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
