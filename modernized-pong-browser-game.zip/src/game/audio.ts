/**
 * Tiny WebAudio synth. No assets, no network, instant startup.
 * Every sound is generated with oscillators + short noise bursts.
 */
type ToneOptions = {
  from: number;
  to?: number;
  duration?: number;
  type?: OscillatorType;
  volume?: number;
  delay?: number;
  curve?: "exp" | "lin";
};

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  muted = false;

  unlock() {
    try {
      if (!this.ctx) {
        const Ctor =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return;
        this.ctx = new Ctor();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.62;
        const comp = this.ctx.createDynamicsCompressor();
        comp.threshold.value = -18;
        comp.knee.value = 20;
        comp.ratio.value = 6;
        this.master.connect(comp);
        comp.connect(this.ctx.destination);
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.62, this.ctx.currentTime, 0.015);
    }
  }

  private tone({
    from,
    to,
    duration = 0.1,
    type = "sine",
    volume = 0.14,
    delay = 0,
    curve = "exp",
  }: ToneOptions) {
    if (this.muted || !this.ctx || !this.master) return;
    try {
      const ctx = this.ctx;
      const t0 = ctx.currentTime + delay;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(30, from), t0);
      if (to) {
        if (curve === "exp") {
          osc.frequency.exponentialRampToValueAtTime(Math.max(30, to), t0 + duration);
        } else {
          osc.frequency.linearRampToValueAtTime(Math.max(30, to), t0 + duration);
        }
      }
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), t0 + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
      osc.connect(gain);
      gain.connect(this.master);
      osc.start(t0);
      osc.stop(t0 + duration + 0.02);
    } catch {
      /* audio is a bonus, never break the game */
    }
  }

  private noise(volume = 0.12, duration = 0.14, frequency = 1400, delay = 0) {
    if (this.muted || !this.ctx || !this.master) return;
    try {
      const ctx = this.ctx;
      const t0 = ctx.currentTime + delay;
      const length = Math.max(1, Math.floor(ctx.sampleRate * duration));
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i += 1) {
        data[i] = (Math.random() * 2 - 1) * (1 - i / length) ** 2;
      }
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.value = frequency;
      filter.Q.value = 0.8;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume, t0);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
      source.connect(filter);
      filter.connect(gain);
      gain.connect(this.master);
      source.start(t0);
    } catch {
      /* noop */
    }
  }

  hit(combo: number, player: boolean) {
    const step = Math.min(combo, 9);
    if (player) {
      this.tone({ from: 190 + step * 26, to: 330 + step * 34, duration: 0.09, type: "triangle", volume: 0.17 });
      this.noise(0.05, 0.05, 2400);
    } else {
      this.tone({ from: 150, to: 200, duration: 0.08, type: "square", volume: 0.055 });
    }
  }

  wall() {
    this.tone({ from: 420, to: 280, duration: 0.05, type: "sine", volume: 0.045 });
  }

  playerScore() {
    this.tone({ from: 523, to: 620, duration: 0.12, type: "triangle", volume: 0.14 });
    this.tone({ from: 784, to: 880, duration: 0.16, type: "triangle", volume: 0.13, delay: 0.08 });
    this.tone({ from: 1046, to: 1200, duration: 0.2, type: "sine", volume: 0.1, delay: 0.16 });
    this.noise(0.1, 0.18, 900);
  }

  rivalScore() {
    this.tone({ from: 210, to: 82, duration: 0.34, type: "sawtooth", volume: 0.11 });
    this.noise(0.07, 0.22, 320);
  }

  power() {
    [660, 880, 1320].forEach((freq, i) =>
      this.tone({ from: freq, to: freq * 1.12, duration: 0.12, type: "triangle", volume: 0.1, delay: i * 0.055 }),
    );
  }

  shield() {
    this.noise(0.14, 0.28, 2600);
    this.tone({ from: 320, to: 980, duration: 0.24, type: "sine", volume: 0.12 });
  }

  surge() {
    this.tone({ from: 130, to: 960, duration: 0.28, type: "sawtooth", volume: 0.1 });
    this.noise(0.13, 0.3, 1800);
  }

  ui() {
    this.tone({ from: 740, to: 920, duration: 0.055, type: "sine", volume: 0.06 });
  }

  pause() {
    this.tone({ from: 440, to: 330, duration: 0.1, type: "sine", volume: 0.06 });
  }

  gameOver(won: boolean) {
    if (won) {
      [523, 659, 784, 1046].forEach((freq, i) =>
        this.tone({ from: freq, to: freq * 1.01, duration: 0.3, type: "triangle", volume: 0.11, delay: i * 0.11 }),
      );
      this.noise(0.07, 0.4, 1200);
    } else {
      [392, 330, 262, 196].forEach((freq, i) =>
        this.tone({ from: freq, to: freq * 0.98, duration: 0.28, type: "sawtooth", volume: 0.07, delay: i * 0.12 }),
      );
    }
  }

  serve() {
    this.tone({ from: 280, to: 380, duration: 0.07, type: "sine", volume: 0.055 });
  }


  /* ------------------------------------------------------------------ */
  /* Match & combo sound events                                         */
  /* ------------------------------------------------------------------ */

  start() {
    // Rising match-start fanfare.
    this.tone({ from: 220, to: 440, duration: 0.24, type: "sine", volume: 0.11 });
    this.tone({ from: 440, to: 587.33, duration: 0.26, type: "triangle", volume: 0.1, delay: 0.08 });
    this.tone({ from: 587.33, to: 880, duration: 0.28, type: "sine", volume: 0.08, delay: 0.17 });
    this.noise(0.05, 0.3, 1500, 0.03);
  }

  comboMilestone(n: number) {
    // Sparkle arpeggio celebrating a bigger combo chain.
    const steps = Math.min(Math.max(n, 1), 7);
    const base = 600 + steps * 55;
    [0, 1, 2].forEach((i) => {
      const freq = base * (1 + i * 0.12);
      this.tone({
        from: freq,
        to: freq * 1.28,
        duration: 0.11,
        type: "triangle",
        volume: 0.05 + i * 0.02,
        delay: i * 0.055,
      });
    });
  }

  comboBreak() {
    // Chain broken — short stepped-down descent.
    this.tone({ from: 330, to: 165, duration: 0.13, type: "square", volume: 0.042 });
    this.tone({ from: 165, to: 82, duration: 0.2, type: "sine", volume: 0.075, delay: 0.06 });
  }

  orbSpawn() {
    // Soft chime so the player notices the drop.
    this.tone({ from: 1046, to: 1318, duration: 0.1, type: "sine", volume: 0.042 });
    this.tone({ from: 1568, to: 1760, duration: 0.14, type: "sine", volume: 0.028, delay: 0.08 });
  }

  surgeReady() {
    // Triad that signals the power shot is armed.
    [0, 1, 2].forEach((i) => {
      const freq = 523 * (1 + i * 0.26);
      this.tone({ from: freq, duration: 0.16, type: "triangle", volume: 0.055, delay: i * 0.06 });
    });
  }

  /* ------------------------------------------------------------------ */
  /* Ambient drone (kept very quiet, only for the live match)          */
  /* ------------------------------------------------------------------ */

  private ambient: { osc: OscillatorNode; gain: GainNode } | null = null;

  startAmbience() {
    if (this.muted || !this.ctx || !this.master || this.ambient) return;
    try {
      const ctx = this.ctx;
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 46;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 150;
      filter.Q.value = 1.2;
      const gain = ctx.createGain();
      gain.gain.value = 0.0001;
      gain.gain.setTargetAtTime(0.024, ctx.currentTime, 0.5);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.master);
      osc.start();
      this.ambient = { osc, gain };
    } catch {
      /* ambience is optional */
    }
  }

  stopAmbience() {
    if (!this.ctx || !this.ambient) return;
    const { osc, gain } = this.ambient;
    this.ambient = null;
    try {
      gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.18);
      window.setTimeout(() => {
        try { osc.stop(); } catch { /* noop */ }
        try { osc.disconnect(); gain.disconnect(); } catch { /* noop */ }
      }, 450);
    } catch {
      /* noop */
    }
  }

  dispose() {
    try {
      void this.ctx?.close();
    } catch {
      /* noop */
    }
    this.ctx = null;
    this.master = null;
  }
}
